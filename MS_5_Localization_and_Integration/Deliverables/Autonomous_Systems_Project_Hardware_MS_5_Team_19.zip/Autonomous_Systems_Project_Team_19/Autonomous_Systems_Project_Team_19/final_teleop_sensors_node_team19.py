#!/usr/bin/env python3

import sys
import time
import re
import termios
import tty
import select
import serial

import rclpy
from rclpy.node import Node

from std_msgs.msg import String, Int32, Float32, Bool


HELP = """
Team 19 Final Teleop + Sensors Node
-----------------------------------
This is the ONLY Raspberry Pi node that opens /dev/ttyACM0.

Controls:
Up Arrow / w       : increase forward RPM
Down Arrow / x     : decrease RPM / go reverse
Left Arrow         : steer left
Right Arrow        : steer right
c                  : center steering
Space / s          : stop motor
z                  : zero encoder + distance + x/y
i                  : zero IMU heading theta
r                  : reset all states + center steering
q                  : stop + reset Arduino + quit

Safety:
Test first with motor battery OFF, then wheels lifted, then on ground.
"""


class FinalTeleopSensorsNode(Node):
    def __init__(self):
        super().__init__('final_teleop_sensors_node_team19')

        self.declare_parameter('port', '/dev/ttyACM0')
        self.declare_parameter('baud', 9600)
        self.declare_parameter('rpm_step', 15.0)
        self.declare_parameter('max_rpm', 210.0)
        self.declare_parameter('print_raw', False)
        self.declare_parameter('print_dashboard', True)

        self.port = self.get_parameter('port').value
        self.baud = int(self.get_parameter('baud').value)
        self.rpm_step = float(self.get_parameter('rpm_step').value)
        self.max_rpm = float(self.get_parameter('max_rpm').value)
        self.print_raw = bool(self.get_parameter('print_raw').value)
        self.print_dashboard = bool(self.get_parameter('print_dashboard').value)

        self.rx_buffer = ''
        self.target_rpm = 0.0
        self.last_dashboard_time = 0.0

        self.state = {
            'T': 0.0,
            'CMD': 0.0,
            'ACT': 0.0,
            'SPEED': 0.0,
            'DIST': 0.0,
            'X': 0.0,
            'Y': 0.0,
            'E': 0,
            'A': 90.0,
            'DELTA': 0.0,
            'IMU': 0,
            'THETA': 0.0,
            'ROLL': 0.0,
            'PITCH': 0.0,
            'GZ': 0.0,
            'AX': 0.0,
            'AY': 0.0,
            'AZ': 0.0,
            'PWM': 0,
            'DIR': 0,
        }

        # Raw and command topics
        self.raw_pub = self.create_publisher(String, '/vehicle/state_raw', 10)
        self.cmd_sub = self.create_subscription(String, '/vehicle/cmd', self.external_cmd_callback, 10)

        # Motor / encoder / odometry topics
        self.target_rpm_pub = self.create_publisher(Float32, '/vehicle/target_rpm', 10)
        self.command_rpm_pub = self.create_publisher(Float32, '/vehicle/command_rpm', 10)
        self.actual_rpm_pub = self.create_publisher(Float32, '/vehicle/actual_rpm', 10)
        self.speed_cmps_pub = self.create_publisher(Float32, '/vehicle/speed_cmps', 10)
        self.speed_mps_pub = self.create_publisher(Float32, '/vehicle/speed_mps', 10)
        self.distance_cm_pub = self.create_publisher(Float32, '/vehicle/distance_cm', 10)
        self.distance_m_pub = self.create_publisher(Float32, '/vehicle/distance_m', 10)
        self.x_m_pub = self.create_publisher(Float32, '/vehicle/x_m', 10)
        self.y_m_pub = self.create_publisher(Float32, '/vehicle/y_m', 10)
        self.encoder_pub = self.create_publisher(Int32, '/vehicle/encoder_count', 10)
        self.pwm_pub = self.create_publisher(Int32, '/vehicle/pwm', 10)
        self.dir_pub = self.create_publisher(Int32, '/vehicle/direction', 10)

        # Steering topics
        self.steering_angle_pub = self.create_publisher(Float32, '/vehicle/steering_angle_deg', 10)
        self.steering_delta_pub = self.create_publisher(Float32, '/vehicle/steering_delta_deg', 10)

        # IMU topics
        self.imu_ok_pub = self.create_publisher(Bool, '/vehicle/imu_ok', 10)
        self.theta_pub = self.create_publisher(Float32, '/vehicle/imu_theta_deg', 10)
        self.roll_pub = self.create_publisher(Float32, '/vehicle/imu_roll_deg', 10)
        self.pitch_pub = self.create_publisher(Float32, '/vehicle/imu_pitch_deg', 10)
        self.gz_pub = self.create_publisher(Float32, '/vehicle/imu_gz_dps', 10)
        self.ax_pub = self.create_publisher(Float32, '/vehicle/imu_ax_g', 10)
        self.ay_pub = self.create_publisher(Float32, '/vehicle/imu_ay_g', 10)
        self.az_pub = self.create_publisher(Float32, '/vehicle/imu_az_g', 10)

        try:
            self.ser = serial.Serial(
                self.port,
                self.baud,
                timeout=0.0,
                write_timeout=0.1
            )
            time.sleep(2.0)
            self.ser.reset_input_buffer()
        except Exception as e:
            self.get_logger().error(f'Failed to open serial port {self.port}: {e}')
            raise

        self.get_logger().info(f'Connected to Arduino on {self.port} @ {self.baud}')
        self.get_logger().info('Final teleop + sensors node started')
        print(HELP)

        # Stop safely at startup
        self.send_to_arduino('STOP')

        self.timer = self.create_timer(0.01, self.timer_callback)

    def make_float_msg(self, value):
        msg = Float32()
        msg.data = float(value)
        return msg

    def make_int_msg(self, value):
        msg = Int32()
        msg.data = int(float(value))
        return msg

    def make_bool_msg(self, value):
        msg = Bool()
        msg.data = bool(int(float(value)))
        return msg

    def send_to_arduino(self, cmd):
        try:
            self.ser.write((str(cmd).strip() + '\n').encode('utf-8'))
            self.ser.flush()
        except Exception as e:
            self.get_logger().error(f'Failed to send command {cmd}: {e}')

    def external_cmd_callback(self, msg):
        cmd = msg.data.strip()
        if cmd:
            self.send_to_arduino(cmd)

    def parse_state_line(self, line):
        pairs = dict(re.findall(r'([A-Z]+)=(-?\d+(?:\.\d+)?)', line))
        if not pairs:
            return

        for key, value in pairs.items():
            if key in ['E', 'PWM', 'DIR', 'IMU']:
                self.state[key] = int(float(value))
            else:
                self.state[key] = float(value)

        # Keep local target synchronized with Arduino target.
        if 'T' in pairs:
            self.target_rpm = float(pairs['T'])

        self.publish_state_topics()

    def publish_state_topics(self):
        s = self.state

        self.target_rpm_pub.publish(self.make_float_msg(s['T']))
        self.command_rpm_pub.publish(self.make_float_msg(s['CMD']))
        self.actual_rpm_pub.publish(self.make_float_msg(s['ACT']))
        self.speed_cmps_pub.publish(self.make_float_msg(s['SPEED']))
        self.speed_mps_pub.publish(self.make_float_msg(s['SPEED'] / 100.0))
        self.distance_cm_pub.publish(self.make_float_msg(s['DIST']))
        self.distance_m_pub.publish(self.make_float_msg(s['DIST'] / 100.0))
        self.x_m_pub.publish(self.make_float_msg(s['X']))
        self.y_m_pub.publish(self.make_float_msg(s['Y']))
        self.encoder_pub.publish(self.make_int_msg(s['E']))
        self.pwm_pub.publish(self.make_int_msg(s['PWM']))
        self.dir_pub.publish(self.make_int_msg(s['DIR']))

        self.steering_angle_pub.publish(self.make_float_msg(s['A']))
        self.steering_delta_pub.publish(self.make_float_msg(s['DELTA']))

        self.imu_ok_pub.publish(self.make_bool_msg(s['IMU']))
        self.theta_pub.publish(self.make_float_msg(s['THETA']))
        self.roll_pub.publish(self.make_float_msg(s['ROLL']))
        self.pitch_pub.publish(self.make_float_msg(s['PITCH']))
        self.gz_pub.publish(self.make_float_msg(s['GZ']))
        self.ax_pub.publish(self.make_float_msg(s['AX']))
        self.ay_pub.publish(self.make_float_msg(s['AY']))
        self.az_pub.publish(self.make_float_msg(s['AZ']))

    def process_line(self, line):
        line = line.strip()
        if not line:
            return

        raw_msg = String()
        raw_msg.data = line
        self.raw_pub.publish(raw_msg)

        if self.print_raw:
            self.get_logger().info(f'Arduino: {line}')

        if line.startswith('STATE'):
            self.parse_state_line(line)

    def read_serial(self):
        try:
            waiting = self.ser.in_waiting
            if waiting <= 0:
                return

            data = self.ser.read(waiting).decode('utf-8', errors='ignore')
            if not data:
                return

            self.rx_buffer += data

            if len(self.rx_buffer) > 3000:
                self.rx_buffer = self.rx_buffer[-1000:]

            while '\n' in self.rx_buffer:
                line, self.rx_buffer = self.rx_buffer.split('\n', 1)
                line = line.replace('\r', '')
                self.process_line(line)

        except Exception as e:
            self.get_logger().error(f'Serial read error: {e}')

    def clamp_target(self):
        if self.target_rpm > self.max_rpm:
            self.target_rpm = self.max_rpm
        if self.target_rpm < -self.max_rpm:
            self.target_rpm = -self.max_rpm

    def handle_key(self, key):
        if key == '\x1b[A' or key.lower() == 'w':
            self.target_rpm += self.rpm_step
            self.clamp_target()
            self.send_to_arduino(f'{self.target_rpm:.1f}')

        elif key == '\x1b[B' or key.lower() == 'x':
            self.target_rpm -= self.rpm_step
            self.clamp_target()
            self.send_to_arduino(f'{self.target_rpm:.1f}')

        elif key == '\x1b[D':
            self.send_to_arduino('L')

        elif key == '\x1b[C':
            self.send_to_arduino('R')

        elif key.lower() == 'c':
            self.send_to_arduino('CENTER')

        elif key == ' ' or key.lower() == 's':
            self.target_rpm = 0.0
            self.send_to_arduino('STOP')

        elif key.lower() == 'z':
            self.send_to_arduino('ZEROENC')

        elif key.lower() == 'i':
            self.send_to_arduino('ZEROIMU')

        elif key.lower() == 'r':
            self.target_rpm = 0.0
            self.send_to_arduino('CLEAR')

        elif key.lower() == 'q':
            self.target_rpm = 0.0
            self.send_to_arduino('STOP')
            time.sleep(0.05)
            self.send_to_arduino('RESET')
            raise KeyboardInterrupt

    def print_dashboard_line(self):
        if not self.print_dashboard:
            return

        now = time.time()
        if now - self.last_dashboard_time < 0.10:
            return

        self.last_dashboard_time = now
        s = self.state

        print(
            f"\rT={s['T']:6.1f} RPM | "
            f"ACT={s['ACT']:6.1f} | "
            f"v={s['SPEED']:7.2f} cm/s | "
            f"d={s['DIST']:8.2f} cm | "
            f"x={s['X']:6.3f} m y={s['Y']:6.3f} m | "
            f"theta={s['THETA']:7.2f} | "
            f"steer={s['A']:5.1f} | "
            f"PWM={s['PWM']:3d} DIR={s['DIR']:+d} | "
            f"↑↓ motor  ←→ steer  SPACE stop  z zero  i imu  q quit"
            "\033[K",
            end='',
            flush=True
        )

    def timer_callback(self):
        self.read_serial()
        self.print_dashboard_line()

    def close(self):
        try:
            self.send_to_arduino('STOP')
            time.sleep(0.05)
            if self.ser and self.ser.is_open:
                self.ser.close()
        except Exception:
            pass


def get_key(timeout=0.01):
    rlist, _, _ = select.select([sys.stdin], [], [], timeout)
    if not rlist:
        return ''

    ch1 = sys.stdin.read(1)
    if ch1 == '\x1b':
        ch2 = sys.stdin.read(1)
        ch3 = sys.stdin.read(1)
        return ch1 + ch2 + ch3

    return ch1


def main(args=None):
    rclpy.init(args=args)
    node = FinalTeleopSensorsNode()

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)

    try:
        tty.setraw(fd)

        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.001)
            key = get_key(timeout=0.005)
            if key:
                node.handle_key(key)

    except KeyboardInterrupt:
        pass

    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        node.close()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
        print('\nStopped motor, closed serial, and exited final node.')


if __name__ == '__main__':
    main()
