#!/usr/bin/env python3
"""
TEAM 19 - Raspberry Pi All-Processing Teleoperation Node

Arduino is only a low-level I/O board:
- receive signed PWM + servo pulse
- count encoder
- read raw MPU6050
- send raw CSV state

This ROS 2 node does all processing:
- keyboard teleoperation
- smooth PWM ramp
- encoder RPM/speed/distance
- IMU roll/pitch/yaw integration
- x/y odometry
- ROS topic publishing
"""

import math
import re
import sys
import time
import termios
import tty
import select
import serial

import rclpy
from rclpy.node import Node

from std_msgs.msg import Bool, Float32, Int32, String


STATE_RE = re.compile(
    r"^S,(-?\d+),(-?\d+),(-?\d+),(-?\d+),(-?\d+),(-?\d+),(-?\d+),(-?\d+),(-?\d+),(-?\d+),(-?\d+)"
)


HELP = """
Final RPi Processing Teleop
---------------------------
Up Arrow / w       : increase forward PWM target
Down Arrow / x     : decrease PWM target / reverse
Left Arrow / a     : steer left
Right Arrow / d    : steer right
c                  : center steering
Space / s          : stop motor immediately
z                  : zero encoder, distance, x, y
I / i              : zero IMU theta
r                  : reset all states and center steering
q                  : stop motor and quit

Arduino is low-level only. Raspberry Pi computes speed, distance, theta, x, y.
"""


def clamp(value, lo, hi):
    return max(lo, min(hi, value))


def wrap_angle_deg(angle):
    while angle > 180.0:
        angle -= 360.0
    while angle < -180.0:
        angle += 360.0
    return angle


def get_key(timeout=0.001):
    rlist, _, _ = select.select([sys.stdin], [], [], timeout)
    if not rlist:
        return ""

    ch1 = sys.stdin.read(1)
    if ch1 == "\x1b":
        # Arrow key sequence
        ch2 = sys.stdin.read(1)
        ch3 = sys.stdin.read(1)
        return ch1 + ch2 + ch3

    return ch1


class FinalTeleopSensorsNode(Node):
    def __init__(self):
        super().__init__('final_rpi_processing_teleop_team19')

        # Serial
        self.declare_parameter('port', '/dev/ttyACM0')
        self.declare_parameter('baud', 9600)

        # Vehicle parameters
       # self.declare_parameter('ppr', 374.0)
        self.declare_parameter('ppr', 1087.0)
        self.declare_parameter('wheel_diameter_cm', 6.5)
        self.declare_parameter('encoder_sign', 1.0)

        # Teleop parameters
        self.declare_parameter('pwm_step', 15.0)
        self.declare_parameter('pwm_ramp_per_sec', 900.0)
        self.declare_parameter('max_pwm', 255.0)
        self.declare_parameter('steer_step_us', 35)
        self.declare_parameter('steer_center_us', 1500)
        self.declare_parameter('steer_min_us', 1000)
        self.declare_parameter('steer_max_us', 2000)
        self.declare_parameter('steer_max_deg', 30.0)

        # Filtering/calibration
        self.declare_parameter('speed_filter_alpha', 0.35)
        self.declare_parameter('gyro_calib_seconds', 2.0)
        self.declare_parameter('cmd_rate_hz', 30.0)

        self.port = self.get_parameter('port').value
        self.baud = int(self.get_parameter('baud').value)

        self.ppr = float(self.get_parameter('ppr').value)
        self.wheel_diameter_cm = float(self.get_parameter('wheel_diameter_cm').value)
        self.encoder_sign = float(self.get_parameter('encoder_sign').value)
        self.wheel_circ_m = math.pi * (self.wheel_diameter_cm / 100.0)

        self.pwm_step = float(self.get_parameter('pwm_step').value)
        self.pwm_ramp_per_sec = float(self.get_parameter('pwm_ramp_per_sec').value)
        self.max_pwm = float(self.get_parameter('max_pwm').value)

        self.steer_step_us = int(self.get_parameter('steer_step_us').value)
        self.steer_center_us = int(self.get_parameter('steer_center_us').value)
        self.steer_min_us = int(self.get_parameter('steer_min_us').value)
        self.steer_max_us = int(self.get_parameter('steer_max_us').value)
        self.steer_max_deg = float(self.get_parameter('steer_max_deg').value)

        self.speed_alpha = float(self.get_parameter('speed_filter_alpha').value)
        self.gyro_calib_seconds = float(self.get_parameter('gyro_calib_seconds').value)
        self.cmd_period = 1.0 / float(self.get_parameter('cmd_rate_hz').value)

        # Teleop command state
        self.target_pwm = 0.0
        self.command_pwm = 0.0
        self.last_ramp_time = time.time()
        self.last_cmd_send = 0.0
        self.last_sent_pwm = None
        self.last_sent_servo = None

        self.servo_us = self.steer_center_us

        # Raw Arduino state
        self.rx_buffer = ""
        self.arduino_ms = None
        self.encoder_count_raw = 0
        self.encoder_count = 0.0
        self.last_encoder_count = None
        self.last_encoder_time = None

        self.ax_raw = self.ay_raw = self.az_raw = 0
        self.gx_raw = self.gy_raw = self.gz_raw = 0
        self.arduino_pwm = 0
        self.arduino_servo_us = self.steer_center_us
        self.imu_ok = False

        # Processed state
        self.actual_rpm = 0.0
        self.speed_mps = 0.0
        self.distance_m = 0.0
        self.x_m = 0.0
        self.y_m = 0.0

        self.ax_g = self.ay_g = self.az_g = 0.0
        self.gx_dps = self.gy_dps = self.gz_dps = 0.0
        self.gz_bias = 0.0
        self.gyro_calibrated = False
        self.calib_samples = []
        self.calib_start_time = None

        self.theta_deg = 0.0
        self.roll_deg = 0.0
        self.pitch_deg = 0.0
        self.last_imu_time = None

        # Publishers
        self.raw_pub = self.create_publisher(String, '/vehicle/state_raw', 10)
        self.imu_ok_pub = self.create_publisher(Bool, '/vehicle/imu_ok', 10)

        self.target_pwm_pub = self.create_publisher(Int32, '/vehicle/target_pwm', 10)
        self.command_pwm_pub = self.create_publisher(Int32, '/vehicle/command_pwm', 10)
        self.applied_pwm_pub = self.create_publisher(Int32, '/vehicle/applied_pwm', 10)

        self.encoder_pub = self.create_publisher(Int32, '/vehicle/encoder_count', 10)
        self.rpm_pub = self.create_publisher(Float32, '/vehicle/actual_rpm', 10)
        self.speed_mps_pub = self.create_publisher(Float32, '/vehicle/speed_mps', 10)
        self.speed_cmps_pub = self.create_publisher(Float32, '/vehicle/speed_cmps', 10)
        self.distance_m_pub = self.create_publisher(Float32, '/vehicle/distance_m', 10)
        self.distance_cm_pub = self.create_publisher(Float32, '/vehicle/distance_cm', 10)
        self.x_pub = self.create_publisher(Float32, '/vehicle/x_m', 10)
        self.y_pub = self.create_publisher(Float32, '/vehicle/y_m', 10)

        self.theta_pub = self.create_publisher(Float32, '/vehicle/imu_theta_deg', 10)
        self.roll_pub = self.create_publisher(Float32, '/vehicle/imu_roll_deg', 10)
        self.pitch_pub = self.create_publisher(Float32, '/vehicle/imu_pitch_deg', 10)
        self.gz_pub = self.create_publisher(Float32, '/vehicle/imu_gz_dps', 10)
        self.ax_pub = self.create_publisher(Float32, '/vehicle/imu_ax_g', 10)
        self.ay_pub = self.create_publisher(Float32, '/vehicle/imu_ay_g', 10)
        self.az_pub = self.create_publisher(Float32, '/vehicle/imu_az_g', 10)

        self.servo_us_pub = self.create_publisher(Int32, '/vehicle/servo_us', 10)
        self.steer_delta_pub = self.create_publisher(Float32, '/vehicle/steering_delta_deg', 10)

        # Serial open
        try:
            self.ser = serial.Serial(self.port, self.baud, timeout=0.0, write_timeout=0.02)
            time.sleep(2.0)  # Arduino resets when serial opens
            self.ser.reset_input_buffer()
        except Exception as e:
            self.get_logger().error(f'Failed to open serial port {self.port}: {e}')
            raise

        self.get_logger().info(f'Connected to Arduino on {self.port} @ {self.baud}')
        self.get_logger().info('Keep the car still for IMU gyro calibration.')
        print(HELP)

    # -----------------------------
    # ROS publishing helpers
    # -----------------------------
    def pub_int(self, pub, value):
        msg = Int32()
        msg.data = int(round(value))
        pub.publish(msg)

    def pub_float(self, pub, value):
        msg = Float32()
        msg.data = float(value)
        pub.publish(msg)

    def pub_bool(self, pub, value):
        msg = Bool()
        msg.data = bool(value)
        pub.publish(msg)

    def pub_string(self, pub, value):
        msg = String()
        msg.data = str(value)
        pub.publish(msg)

    # -----------------------------
    # Serial command
    # -----------------------------
    def send_command(self, force=False):
        now = time.time()

        pwm_i = int(round(self.command_pwm))
        servo_i = int(self.servo_us)

        changed = (pwm_i != self.last_sent_pwm) or (servo_i != self.last_sent_servo)
        heartbeat_due = (now - self.last_cmd_send) >= 0.20
        rate_due = (now - self.last_cmd_send) >= self.cmd_period

        if not force and not ((changed and rate_due) or heartbeat_due):
            return

        cmd = f'C,{pwm_i},{servo_i}\n'
        try:
            self.ser.write(cmd.encode('utf-8'))
            self.last_cmd_send = now
            self.last_sent_pwm = pwm_i
            self.last_sent_servo = servo_i
        except Exception as e:
            self.get_logger().error(f'Serial write error: {e}')

    def send_text_command(self, text):
        try:
            self.ser.write((text + '\n').encode('utf-8'))
            self.ser.flush()
        except Exception as e:
            self.get_logger().error(f'Serial write error: {e}')

    # -----------------------------
    # Keyboard
    # -----------------------------
    def handle_key(self, key):
        if not key:
            return True

        if key == '\x1b[A' or key.lower() == 'w':
            self.target_pwm += self.pwm_step
            self.target_pwm = clamp(self.target_pwm, -self.max_pwm, self.max_pwm)

        elif key == '\x1b[B' or key.lower() == 'x':
            self.target_pwm -= self.pwm_step
            self.target_pwm = clamp(self.target_pwm, -self.max_pwm, self.max_pwm)

        elif key == '\x1b[D' or key.lower() == 'a':
            self.servo_us -= self.steer_step_us
            self.servo_us = int(clamp(self.servo_us, self.steer_min_us, self.steer_max_us))

        elif key == '\x1b[C' or key.lower() == 'd':
            self.servo_us += self.steer_step_us
            self.servo_us = int(clamp(self.servo_us, self.steer_min_us, self.steer_max_us))

        elif key.lower() == 'c':
            self.servo_us = self.steer_center_us

        elif key == ' ' or key.lower() == 's':
            self.target_pwm = 0.0
            self.command_pwm = 0.0
            self.send_text_command('STOP')
            self.send_command(force=True)

        elif key.lower() == 'z':
            self.zero_encoder_odometry()
            self.send_text_command('ZERO')

        elif key.lower() == 'i':
            self.theta_deg = 0.0
            self.last_imu_time = None
            self.get_logger().info('IMU theta zeroed on Raspberry Pi')

        elif key.lower() == 'r':
            self.target_pwm = 0.0
            self.command_pwm = 0.0
            self.servo_us = self.steer_center_us
            self.zero_encoder_odometry()
            self.theta_deg = 0.0
            self.last_imu_time = None
            self.send_text_command('STOP')
            self.send_text_command('ZERO')
            self.send_command(force=True)

        elif key.lower() == 'q':
            self.target_pwm = 0.0
            self.command_pwm = 0.0
            self.send_text_command('STOP')
            self.send_command(force=True)
            return False

        return True

    # -----------------------------
    # Smooth PWM ramp on Raspberry Pi
    # -----------------------------
    def update_ramp(self):
        now = time.time()
        dt = now - self.last_ramp_time
        self.last_ramp_time = now

        max_step = self.pwm_ramp_per_sec * dt

        if self.command_pwm < self.target_pwm:
            self.command_pwm = min(self.command_pwm + max_step, self.target_pwm)
        elif self.command_pwm > self.target_pwm:
            self.command_pwm = max(self.command_pwm - max_step, self.target_pwm)

        self.command_pwm = clamp(self.command_pwm, -self.max_pwm, self.max_pwm)

    # -----------------------------
    # Serial read and parsing
    # -----------------------------
    def read_serial(self):
        try:
            waiting = self.ser.in_waiting
            if waiting <= 0:
                return

            data = self.ser.read(waiting).decode('utf-8', errors='ignore')
            if not data:
                return

            self.rx_buffer += data

            if len(self.rx_buffer) > 2000:
                self.rx_buffer = self.rx_buffer[-500:]

            while '\n' in self.rx_buffer:
                line, self.rx_buffer = self.rx_buffer.split('\n', 1)
                line = line.strip().replace('\r', '')
                if line:
                    self.process_line(line)

        except Exception as e:
            self.get_logger().error(f'Serial read error: {e}')

    def process_line(self, line):
        self.pub_string(self.raw_pub, line)

        if line.startswith('READY') or line.startswith('A,'):
            # Acknowledgement / boot messages
            return

        m = STATE_RE.match(line)
        if not m:
            return

        (
            t_ms, enc, ax, ay, az, gx, gy, gz,
            applied_pwm, servo_us, imu_ok
        ) = m.groups()

        t_ms = int(t_ms)
        enc = int(enc)
        ax = int(ax)
        ay = int(ay)
        az = int(az)
        gx = int(gx)
        gy = int(gy)
        gz = int(gz)
        applied_pwm = int(applied_pwm)
        servo_us = int(servo_us)
        imu_ok = int(imu_ok) == 1

        self.arduino_ms = t_ms
        self.encoder_count_raw = enc
        self.encoder_count = self.encoder_sign * enc
        self.ax_raw, self.ay_raw, self.az_raw = ax, ay, az
        self.gx_raw, self.gy_raw, self.gz_raw = gx, gy, gz
        self.arduino_pwm = applied_pwm
        self.arduino_servo_us = servo_us
        self.imu_ok = imu_ok

        now = time.time()
        self.process_encoder(now)
        self.process_imu(now)
        self.publish_all()

    # -----------------------------
    # Processing on RPi
    # -----------------------------
    def process_encoder(self, now):
        count = self.encoder_count

        if self.last_encoder_count is None:
            self.last_encoder_count = count
            self.last_encoder_time = now
            self.distance_m = (count / self.ppr) * self.wheel_circ_m
            return

        dt = now - self.last_encoder_time
        if dt <= 0.0:
            return

        delta = count - self.last_encoder_count

        raw_rpm = (delta / self.ppr) * (60.0 / dt)
        raw_speed = raw_rpm * self.wheel_circ_m / 60.0

        self.actual_rpm = (self.speed_alpha * raw_rpm) + ((1.0 - self.speed_alpha) * self.actual_rpm)
        self.speed_mps = (self.speed_alpha * raw_speed) + ((1.0 - self.speed_alpha) * self.speed_mps)

        # Absolute distance from total encoder count
        self.distance_m = (count / self.ppr) * self.wheel_circ_m

        # Deadband very tiny noise
        if abs(self.speed_mps) < 0.002 and abs(self.command_pwm) < 5:
            self.speed_mps = 0.0
            self.actual_rpm = 0.0

        theta_rad = math.radians(self.theta_deg)
        self.x_m += self.speed_mps * math.cos(theta_rad) * dt
        self.y_m += self.speed_mps * math.sin(theta_rad) * dt

        self.last_encoder_count = count
        self.last_encoder_time = now

    def process_imu(self, now):
        if not self.imu_ok:
            return

        # MPU6050 default scaling:
        self.ax_g = self.ax_raw / 16384.0
        self.ay_g = self.ay_raw / 16384.0
        self.az_g = self.az_raw / 16384.0

        self.gx_dps = self.gx_raw / 131.0
        self.gy_dps = self.gy_raw / 131.0
        raw_gz_dps = self.gz_raw / 131.0

        # RPi-side gyro calibration
        if not self.gyro_calibrated:
            if self.calib_start_time is None:
                self.calib_start_time = now
                self.calib_samples = []

            self.calib_samples.append(raw_gz_dps)

            if now - self.calib_start_time >= self.gyro_calib_seconds:
                if self.calib_samples:
                    self.gz_bias = sum(self.calib_samples) / len(self.calib_samples)
                else:
                    self.gz_bias = 0.0
                self.gyro_calibrated = True
                self.last_imu_time = now
                self.get_logger().info(f'Gyro Z calibrated on RPi. Bias = {self.gz_bias:.4f} deg/s')
            return

        self.gz_dps = raw_gz_dps - self.gz_bias

        self.roll_deg = math.degrees(math.atan2(self.ay_g, self.az_g))
        self.pitch_deg = math.degrees(math.atan2(-self.ax_g, math.sqrt(self.ay_g * self.ay_g + self.az_g * self.az_g)))

        if self.last_imu_time is None:
            self.last_imu_time = now
            return

        dt = now - self.last_imu_time
        self.last_imu_time = now

        if 0.0 < dt < 0.5:
            self.theta_deg = wrap_angle_deg(self.theta_deg + self.gz_dps * dt)

    def zero_encoder_odometry(self):
        self.last_encoder_count = None
        self.last_encoder_time = None
        self.actual_rpm = 0.0
        self.speed_mps = 0.0
        self.distance_m = 0.0
        self.x_m = 0.0
        self.y_m = 0.0
        self.get_logger().info('Encoder, distance, x, y zeroed on Raspberry Pi')

    def steering_delta_deg(self):
        span_us = (self.steer_max_us - self.steer_center_us)
        if span_us <= 0:
            return 0.0
        return ((self.servo_us - self.steer_center_us) / span_us) * self.steer_max_deg

    def publish_all(self):
        self.pub_bool(self.imu_ok_pub, self.imu_ok)

        self.pub_int(self.target_pwm_pub, self.target_pwm)
        self.pub_int(self.command_pwm_pub, self.command_pwm)
        self.pub_int(self.applied_pwm_pub, self.arduino_pwm)

        self.pub_int(self.encoder_pub, self.encoder_count)
        self.pub_float(self.rpm_pub, self.actual_rpm)
        self.pub_float(self.speed_mps_pub, self.speed_mps)
        self.pub_float(self.speed_cmps_pub, self.speed_mps * 100.0)
        self.pub_float(self.distance_m_pub, self.distance_m)
        self.pub_float(self.distance_cm_pub, self.distance_m * 100.0)
        self.pub_float(self.x_pub, self.x_m)
        self.pub_float(self.y_pub, self.y_m)

        self.pub_float(self.theta_pub, self.theta_deg)
        self.pub_float(self.roll_pub, self.roll_deg)
        self.pub_float(self.pitch_pub, self.pitch_deg)
        self.pub_float(self.gz_pub, self.gz_dps)
        self.pub_float(self.ax_pub, self.ax_g)
        self.pub_float(self.ay_pub, self.ay_g)
        self.pub_float(self.az_pub, self.az_g)

        self.pub_int(self.servo_us_pub, self.servo_us)
        self.pub_float(self.steer_delta_pub, self.steering_delta_deg())

    # -----------------------------
    # Dashboard
    # -----------------------------
    def print_dashboard(self):
        calib_text = 'OK' if self.gyro_calibrated else 'CAL'
        print(
            f"\rTargetPWM={self.target_pwm:6.1f} | "
            f"CmdPWM={self.command_pwm:6.1f} | "
            f"ArduinoPWM={self.arduino_pwm:4d} | "
            f"RPM={self.actual_rpm:7.1f} | "
            f"v={self.speed_mps:6.3f} m/s | "
            f"d={self.distance_m:7.3f} m | "
            f"x={self.x_m:6.3f} y={self.y_m:6.3f} | "
            f"theta={self.theta_deg:7.2f} | "
            f"roll={self.roll_deg:6.1f} pitch={self.pitch_deg:6.1f} | "
            f"steer={self.steering_delta_deg():6.1f} deg | "
            f"IMU={int(self.imu_ok)} {calib_text} | "
            f"↑/w fwd ↓/x rev SPACE stop z zero i zeroIMU q quit"
            "\033[K",
            end='',
            flush=True
        )

    def close(self):
        try:
            self.target_pwm = 0.0
            self.command_pwm = 0.0
            self.send_text_command('STOP')
            time.sleep(0.05)
        except Exception:
            pass

        try:
            if hasattr(self, 'ser') and self.ser and self.ser.is_open:
                self.ser.close()
        except Exception:
            pass


def main(args=None):
    rclpy.init(args=args)
    node = FinalTeleopSensorsNode()

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    last_display = 0.0

    try:
        tty.setraw(fd)

        # Ensure Arduino receives initial safe command.
        node.send_text_command('STOP')
        node.send_command(force=True)

        keep_running = True
        while rclpy.ok() and keep_running:
            rclpy.spin_once(node, timeout_sec=0.0)

            node.read_serial()

            key = get_key(timeout=0.001)
            keep_running = node.handle_key(key)

            node.update_ramp()
            node.send_command()

            now = time.time()
            if now - last_display >= 0.10:
                last_display = now
                node.print_dashboard()

            time.sleep(0.004)

    except KeyboardInterrupt:
        pass

    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        node.close()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
        print('\nStopped motor, restored terminal, and closed serial.')


if __name__ == '__main__':
    main()
