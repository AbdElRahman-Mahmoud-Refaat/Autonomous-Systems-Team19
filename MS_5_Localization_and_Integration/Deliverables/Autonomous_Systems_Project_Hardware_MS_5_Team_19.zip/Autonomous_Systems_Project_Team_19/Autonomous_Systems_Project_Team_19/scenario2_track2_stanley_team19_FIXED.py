#!/usr/bin/env python3

import math
import sys
import time
import select
import termios
import tty
import serial

import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Float32, Int32, Bool


class Scenario2Track2Stanley(Node):
    """
    Scenario 2 / Track 02 hardware controller.

    Arduino stays low-level only:
      - receives: C,<signed_pwm>,<servo_us>
      - receives: STOP, ZERO
      - sends:    S,time_ms,encoder,ax,ay,az,gx,gy,gz,pwm,servo_us,imu_ok

    Raspberry Pi does:
      - encoder speed and odometry
      - gyro heading integration
      - lane planning
      - Stanley lateral control
      - simple speed control
    """

    def __init__(self):
        super().__init__('Autonomous_Systems_MS_4_Track2_Stanley_Team_19')

        # -------------------------
        # Parameters
        # -------------------------
        self.declare_parameter('port', '/dev/ttyACM0')
        self.declare_parameter('baud', 9600)

        # Use your calibrated value. If distance becomes wrong, retune this.
        self.declare_parameter('ppr', 1085.0)
        self.declare_parameter('wheel_diameter_cm', 6.5)
        self.declare_parameter('encoder_sign', 1.0)   # change to -1.0 if x decreases while moving forward

        # Track 02 geometry
        self.declare_parameter('lane1_y_m', 0.1875)
        self.declare_parameter('lane2_y_m', -0.1875)
        self.declare_parameter('track_end_x_m', 10.0)
        self.declare_parameter('obs1_x_m', 4.0)
        self.declare_parameter('obs2_x_m', 8.0)

        # Lane changes are planned to finish BEFORE the obstacle.
        self.declare_parameter('lane_change_start_before_m', 1.00)   # start 1.0 m before obstacle
        self.declare_parameter('lane_change_end_before_m', 0.15)     # finish 0.15 m before obstacle
        self.declare_parameter('initial_lane_settle_m', 0.90)        # smooth from y=0 to lane 1 at start

        # Speed profile
        self.declare_parameter('normal_speed_mps', 0.20)
        self.declare_parameter('lane_change_speed_mps', 0.12)
        self.declare_parameter('slowdown_distance_m', 0.70)
        self.declare_parameter('stop_tolerance_m', 0.03)

        # Speed-to-PWM controller. Start conservative.
        self.declare_parameter('base_pwm', 120.0)
        self.declare_parameter('min_move_pwm', 80.0)
        self.declare_parameter('max_pwm', 190.0)
        self.declare_parameter('kp_speed_pwm_per_mps', 180.0)
        self.declare_parameter('pwm_ramp_per_sec', 700.0)

        # Stanley steering
        self.declare_parameter('k_stanley', 0.65)
        self.declare_parameter('eps_speed', 0.08)
        self.declare_parameter('heading_gain', 1.0)
        self.declare_parameter('max_steer_deg', 18.0)

        # Servo conversion
        self.declare_parameter('servo_center_us', 1500)
        self.declare_parameter('servo_min_us', 1100)
        self.declare_parameter('servo_max_us', 1900)
        self.declare_parameter('us_per_deg', 11.0)
        self.declare_parameter('steer_sign', 1.0)  # change to -1.0 if steering correction is opposite

        self.port = self.get_parameter('port').value
        self.baud = int(self.get_parameter('baud').value)

        self.ppr = float(self.get_parameter('ppr').value)
        self.encoder_sign = float(self.get_parameter('encoder_sign').value)
        self.wheel_diameter_cm = float(self.get_parameter('wheel_diameter_cm').value)
        self.wheel_circumference_m = math.pi * self.wheel_diameter_cm / 100.0

        self.lane1_y = float(self.get_parameter('lane1_y_m').value)
        self.lane2_y = float(self.get_parameter('lane2_y_m').value)
        self.track_end_x = float(self.get_parameter('track_end_x_m').value)
        self.obs1_x = float(self.get_parameter('obs1_x_m').value)
        self.obs2_x = float(self.get_parameter('obs2_x_m').value)
        self.lane_change_start_before = float(self.get_parameter('lane_change_start_before_m').value)
        self.lane_change_end_before = float(self.get_parameter('lane_change_end_before_m').value)
        self.initial_lane_settle_m = float(self.get_parameter('initial_lane_settle_m').value)

        self.normal_speed = float(self.get_parameter('normal_speed_mps').value)
        self.lane_change_speed = float(self.get_parameter('lane_change_speed_mps').value)
        self.slowdown_distance = float(self.get_parameter('slowdown_distance_m').value)
        self.stop_tolerance = float(self.get_parameter('stop_tolerance_m').value)

        self.base_pwm = float(self.get_parameter('base_pwm').value)
        self.min_move_pwm = float(self.get_parameter('min_move_pwm').value)
        self.max_pwm = float(self.get_parameter('max_pwm').value)
        self.kp_speed = float(self.get_parameter('kp_speed_pwm_per_mps').value)
        self.pwm_ramp_per_sec = float(self.get_parameter('pwm_ramp_per_sec').value)

        self.k_stanley = float(self.get_parameter('k_stanley').value)
        self.eps_speed = float(self.get_parameter('eps_speed').value)
        self.heading_gain = float(self.get_parameter('heading_gain').value)
        self.max_steer_deg = float(self.get_parameter('max_steer_deg').value)

        self.servo_center_us = int(self.get_parameter('servo_center_us').value)
        self.servo_min_us = int(self.get_parameter('servo_min_us').value)
        self.servo_max_us = int(self.get_parameter('servo_max_us').value)
        self.us_per_deg = float(self.get_parameter('us_per_deg').value)
        self.steer_sign = float(self.get_parameter('steer_sign').value)

        # -------------------------
        # Serial
        # -------------------------
        self.ser = serial.Serial(self.port, self.baud, timeout=0.001, write_timeout=0.05)
        time.sleep(2.0)
        self.ser.reset_input_buffer()

        # -------------------------
        # Publishers
        # -------------------------
        self.raw_pub = self.create_publisher(String, '/vehicle/state_raw', 10)
        self.state_pub = self.create_publisher(String, '/vehicle/state_estimated', 10)
        self.cmd_pub = self.create_publisher(String, '/vehicle/cmd', 10)

        self.x_pub = self.create_publisher(Float32, '/vehicle/x_m', 10)
        self.y_pub = self.create_publisher(Float32, '/vehicle/y_m', 10)
        self.theta_pub = self.create_publisher(Float32, '/vehicle/imu_theta_deg', 10)
        self.speed_pub = self.create_publisher(Float32, '/vehicle/speed_mps', 10)
        self.encoder_pub = self.create_publisher(Int32, '/vehicle/encoder_count', 10)

        self.lane_ref_pub = self.create_publisher(Float32, '/scenario2/lane_ref_m', 10)
        self.speed_ref_pub = self.create_publisher(Float32, '/scenario2/speed_ref_mps', 10)
        self.heading_ref_pub = self.create_publisher(Float32, '/scenario2/heading_ref_deg', 10)
        self.cross_track_pub = self.create_publisher(Float32, '/scenario2/crosstrack_error_m', 10)
        self.steer_pub = self.create_publisher(Float32, '/vehicle/steering_delta_deg', 10)
        self.pwm_pub = self.create_publisher(Int32, '/scenario2/pwm_cmd', 10)
        self.auto_pub = self.create_publisher(Bool, '/scenario2/auto_enabled', 10)

        # -------------------------
        # States
        # -------------------------
        self.x = 0.0
        self.y = 0.0
        self.theta_deg = 0.0
        self.theta_rad = 0.0
        self.v = 0.0
        self.v_filt = 0.0
        self.distance_m = 0.0

        self.prev_time_ms = None
        self.prev_encoder = None
        self.last_control_time = time.time()

        self.desired_lane_y = 0.0
        self.desired_heading_rad = 0.0
        self.desired_speed = 0.0
        self.cross_track_error = 0.0
        self.steering_deg = 0.0
        self.pwm_cmd = 0.0

        # Gyro calibration
        self.calibrating = True
        self.gz_offset_sum = 0.0
        self.gz_offset_count = 0
        self.gz_offset = 0.0
        self.calibration_samples = 100

        self.auto_enabled = False
        self.finished = False

        self.timer = self.create_timer(0.02, self.loop)

        self.send_to_arduino(0, self.servo_center_us)
        self.get_logger().info(f'Connected to Arduino on {self.port} @ {self.baud}')
        self.get_logger().info('Keep the car still for gyro calibration.')
        print('\nScenario 2 Track 02 Stanley Controller')
        print('------------------------------------')
        print('a : start autonomous')
        print('s : stop')
        print('z : zero encoder + x/y/theta')
        print('q : quit')
        print('Important: test with small track_end_x_m first before 10 m.\n')

    # -------------------------
    # Helpers
    # -------------------------
    @staticmethod
    def clamp(value, lo, hi):
        return max(lo, min(hi, value))

    @staticmethod
    def normalize_angle_rad(angle):
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle

    @staticmethod
    def smoothstep(u):
        u = max(0.0, min(1.0, u))
        return u * u * (3.0 - 2.0 * u)

    @staticmethod
    def smoothstep_derivative(u):
        u = max(0.0, min(1.0, u))
        return 6.0 * u * (1.0 - u)

    def send_to_arduino(self, pwm, servo_us):
        pwm = int(self.clamp(round(pwm), -255, 255))
        servo_us = int(self.clamp(round(servo_us), self.servo_min_us, self.servo_max_us))
        cmd = f'C,{pwm},{servo_us}\n'
        self.ser.write(cmd.encode('utf-8'))
        self.cmd_pub.publish(String(data=cmd.strip()))

    def stop_car(self):
        self.pwm_cmd = 0.0
        self.desired_speed = 0.0
        self.send_to_arduino(0, self.servo_center_us)

    def zero_states(self):
        self.x = 0.0
        self.y = 0.0
        self.theta_deg = 0.0
        self.theta_rad = 0.0
        self.v = 0.0
        self.v_filt = 0.0
        self.distance_m = 0.0
        self.prev_time_ms = None
        self.prev_encoder = None
        self.finished = False
        self.ser.write(b'ZERO\n')
        time.sleep(0.05)
        self.get_logger().info('States zeroed.')

    def parse_state_line(self, line):
        if not line.startswith('S,'):
            return None
        parts = line.split(',')
        if len(parts) != 12:
            return None
        try:
            return {
                'time_ms': int(parts[1]),
                'encoder': int(parts[2]),
                'ax': int(parts[3]),
                'ay': int(parts[4]),
                'az': int(parts[5]),
                'gx': int(parts[6]),
                'gy': int(parts[7]),
                'gz': int(parts[8]),
                'arduino_pwm': int(parts[9]),
                'arduino_servo': int(parts[10]),
                'imu_ok': int(parts[11]),
            }
        except ValueError:
            return None

    # -------------------------
    # Sensor processing
    # -------------------------
    def update_gyro_calibration(self, gz_raw):
        gz_dps = gz_raw / 131.0
        self.gz_offset_sum += gz_dps
        self.gz_offset_count += 1
        if self.gz_offset_count >= self.calibration_samples:
            self.gz_offset = self.gz_offset_sum / self.gz_offset_count
            self.calibrating = False
            self.get_logger().info(f'Gyro calibration done. gz_offset={self.gz_offset:.4f} deg/s')
            self.get_logger().info('Press a to start.')

    def update_localization(self, state):
        time_ms = state['time_ms']
        encoder = state['encoder']

        if self.prev_time_ms is None:
            self.prev_time_ms = time_ms
            self.prev_encoder = encoder
            return

        dt = (time_ms - self.prev_time_ms) / 1000.0
        delta_encoder = encoder - self.prev_encoder
        self.prev_time_ms = time_ms
        self.prev_encoder = encoder

        if dt <= 0.0 or dt > 0.5:
            return

        ds = self.encoder_sign * (delta_encoder / self.ppr) * self.wheel_circumference_m
        self.distance_m += ds
        self.v = ds / dt
        self.v_filt = 0.75 * self.v_filt + 0.25 * self.v

        gz_dps = (state['gz'] / 131.0) - self.gz_offset
        self.theta_deg += gz_dps * dt
        if self.theta_deg > 180.0:
            self.theta_deg -= 360.0
        elif self.theta_deg < -180.0:
            self.theta_deg += 360.0
        self.theta_rad = math.radians(self.theta_deg)

        self.x += ds * math.cos(self.theta_rad)
        self.y += ds * math.sin(self.theta_rad)

    # -------------------------
    # Planning
    # -------------------------
    def lane_transition(self, x, x0, x1, y0, y1):
        if x <= x0:
            return y0, 0.0
        if x >= x1:
            return y1, 0.0
        L = max(0.001, x1 - x0)
        u = (x - x0) / L
        s = self.smoothstep(u)
        dsdu = self.smoothstep_derivative(u)
        y_ref = y0 + (y1 - y0) * s
        dy_dx = (y1 - y0) * dsdu / L
        return y_ref, dy_dx

    def update_planner(self):
        x = self.x

        # Stop near end of track.
        remaining = self.track_end_x - x
        if remaining <= self.stop_tolerance:
            self.desired_speed = 0.0
            self.auto_enabled = False
            self.finished = True
            self.desired_lane_y = self.lane1_y
            self.desired_heading_rad = 0.0
            return

        # Lane change windows finish before obstacles.
        c1_start = self.obs1_x - self.lane_change_start_before
        c1_end = self.obs1_x - self.lane_change_end_before
        c2_start = self.obs2_x - self.lane_change_start_before
        c2_end = self.obs2_x - self.lane_change_end_before

        # Smooth start from center y=0 to lane 1.
        if x < self.initial_lane_settle_m:
            y_ref, dy_dx = self.lane_transition(x, 0.0, self.initial_lane_settle_m, 0.0, self.lane1_y)
            lane_change = True
        elif x < c1_start:
            y_ref, dy_dx = self.lane1_y, 0.0
            lane_change = False
        elif x < c1_end:
            y_ref, dy_dx = self.lane_transition(x, c1_start, c1_end, self.lane1_y, self.lane2_y)
            lane_change = True
        elif x < c2_start:
            y_ref, dy_dx = self.lane2_y, 0.0
            lane_change = False
        elif x < c2_end:
            y_ref, dy_dx = self.lane_transition(x, c2_start, c2_end, self.lane2_y, self.lane1_y)
            lane_change = True
        else:
            y_ref, dy_dx = self.lane1_y, 0.0
            lane_change = False

        self.desired_lane_y = y_ref
        self.desired_heading_rad = math.atan2(dy_dx, 1.0)
        self.desired_speed = self.lane_change_speed if lane_change else self.normal_speed

        # Slow down before the final stop.
        if remaining < self.slowdown_distance:
            scale = max(0.35, remaining / self.slowdown_distance)
            self.desired_speed *= scale

    # -------------------------
    # Control
    # -------------------------
    def update_speed_controller(self, dt):
        if self.desired_speed <= 0.001:
            target_pwm = 0.0
        else:
            speed_error = self.desired_speed - max(0.0, self.v_filt)
            target_pwm = self.base_pwm + self.kp_speed * speed_error
            target_pwm = self.clamp(target_pwm, self.min_move_pwm, self.max_pwm)

        max_step = self.pwm_ramp_per_sec * dt
        if self.pwm_cmd < target_pwm:
            self.pwm_cmd = min(self.pwm_cmd + max_step, target_pwm)
        else:
            self.pwm_cmd = max(self.pwm_cmd - max_step, target_pwm)

        return int(round(self.pwm_cmd))

    def update_stanley_controller(self):
        heading_error = self.normalize_angle_rad(self.desired_heading_rad - self.theta_rad)
        self.cross_track_error = self.desired_lane_y - self.y

        steering_rad = (self.heading_gain * heading_error) + math.atan2(
            self.k_stanley * self.cross_track_error,
            abs(self.v_filt) + self.eps_speed
        )

        self.steering_deg = math.degrees(steering_rad)
        self.steering_deg = self.clamp(self.steering_deg, -self.max_steer_deg, self.max_steer_deg)

        servo_us = self.servo_center_us + self.steer_sign * self.us_per_deg * self.steering_deg
        servo_us = self.clamp(servo_us, self.servo_min_us, self.servo_max_us)
        return int(round(servo_us))

    # -------------------------
    # Publishing / loop
    # -------------------------
    def publish_all(self, state=None):
        self.state_pub.publish(String(data=(
            f'x={self.x:.3f},y={self.y:.3f},theta={self.theta_deg:.2f},'
            f'v={self.v_filt:.3f},lane_ref={self.desired_lane_y:.4f},'
            f'heading_ref={math.degrees(self.desired_heading_rad):.2f},'
            f'v_ref={self.desired_speed:.3f},cte={self.cross_track_error:.3f},'
            f'steer={self.steering_deg:.2f},pwm={int(self.pwm_cmd)},auto={int(self.auto_enabled)}'
        )))

        self.x_pub.publish(Float32(data=float(self.x)))
        self.y_pub.publish(Float32(data=float(self.y)))
        self.theta_pub.publish(Float32(data=float(self.theta_deg)))
        self.speed_pub.publish(Float32(data=float(self.v_filt)))
        if state is not None:
            self.encoder_pub.publish(Int32(data=int(state['encoder'])))
        self.lane_ref_pub.publish(Float32(data=float(self.desired_lane_y)))
        self.speed_ref_pub.publish(Float32(data=float(self.desired_speed)))
        self.heading_ref_pub.publish(Float32(data=float(math.degrees(self.desired_heading_rad))))
        self.cross_track_pub.publish(Float32(data=float(self.cross_track_error)))
        self.steer_pub.publish(Float32(data=float(self.steering_deg)))
        self.pwm_pub.publish(Int32(data=int(round(self.pwm_cmd))))
        self.auto_pub.publish(Bool(data=bool(self.auto_enabled)))

    def loop(self):
        now = time.time()
        dt_control = now - self.last_control_time
        self.last_control_time = now
        dt_control = self.clamp(dt_control, 0.001, 0.1)

        processed_state = None

        while self.ser.in_waiting > 0:
            line = self.ser.readline().decode('utf-8', errors='ignore').strip()
            if not line:
                continue

            self.raw_pub.publish(String(data=line))

            if not line.startswith('S,'):
                print(line)
                continue

            state = self.parse_state_line(line)
            if state is None:
                continue
            processed_state = state

            if state['imu_ok'] != 1:
                self.get_logger().warn('IMU not OK. Stopping.')
                self.auto_enabled = False
                self.stop_car()
                continue

            if self.calibrating:
                self.update_gyro_calibration(state['gz'])
                self.stop_car()
                return

            self.update_localization(state)

        if self.calibrating:
            return

        if processed_state is None:
            return

        if self.auto_enabled:
            self.update_planner()
            pwm = self.update_speed_controller(dt_control)
            servo = self.update_stanley_controller()
            self.send_to_arduino(pwm, servo)
        else:
            self.stop_car()

        self.publish_all(processed_state)

        print(
            f'\rx={self.x:5.2f} y={self.y:+5.2f} theta={self.theta_deg:+6.2f} | '
            f'y_ref={self.desired_lane_y:+5.3f} hdg_ref={math.degrees(self.desired_heading_rad):+5.1f} | '
            f'v={self.v_filt:4.2f}/{self.desired_speed:4.2f} | '
            f'cte={self.cross_track_error:+5.3f} steer={self.steering_deg:+5.1f} | '
            f'pwm={int(self.pwm_cmd):3d} auto={int(self.auto_enabled)} finished={int(self.finished)}      ',
            end='',
            flush=True
        )

    def start_auto(self):
        if self.calibrating:
            self.get_logger().warn('Still calibrating. Keep car still and wait.')
            return
        self.zero_states()
        self.pwm_cmd = 0.0
        self.auto_enabled = True
        self.finished = False
        self.get_logger().info('Scenario 2 autonomous mode started.')

    def shutdown_safe(self):
        self.auto_enabled = False
        try:
            self.stop_car()
            time.sleep(0.1)
            self.ser.write(b'STOP\n')
            self.ser.close()
        except Exception:
            pass


def get_key(timeout=0.02):
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        rlist, _, _ = select.select([sys.stdin], [], [], timeout)
        if rlist:
            return sys.stdin.read(1)
        return ''
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


def main(args=None):
    rclpy.init(args=args)
    node = Scenario2Track2Stanley()
    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.001)
            key = get_key(0.02)
            if key.lower() == 'a':
                node.start_auto()
            elif key.lower() == 's' or key == ' ':
                node.auto_enabled = False
                node.stop_car()
                node.get_logger().info('Stopped.')
            elif key.lower() == 'z':
                node.zero_states()
            elif key.lower() == 'q':
                break
    except KeyboardInterrupt:
        pass
    finally:
        node.shutdown_safe()
        node.destroy_node()
        rclpy.shutdown()
        print('\nClosed safely.')


if __name__ == '__main__':
    main()
