#!/usr/bin/env python3

import time
import re
import serial

import rclpy
from rclpy.node import Node

from std_msgs.msg import String, Int32, Float32, Bool


class VehicleInterfaceNode(Node):
    def __init__(self):
        super().__init__('vehicle_interface_node')

        self.declare_parameter('port', '/dev/ttyACM0')
        self.declare_parameter('baud', 115200)
        self.declare_parameter('print_raw', True)

        self.port = self.get_parameter('port').value
        self.baud = int(self.get_parameter('baud').value)
        self.print_raw = bool(self.get_parameter('print_raw').value)

        # ROS publishers
        self.raw_pub = self.create_publisher(String, '/vehicle/state_raw', 10)

        self.encoder_pub = self.create_publisher(Int32, '/vehicle/encoder_count', 10)
        self.target_cmd_pub = self.create_publisher(Int32, '/vehicle/target_cmd', 10)
        self.current_cmd_pub = self.create_publisher(Int32, '/vehicle/current_cmd', 10)
        self.steering_angle_pub = self.create_publisher(Float32, '/vehicle/steering_angle_deg', 10)

        self.imu_ok_pub = self.create_publisher(Bool, '/vehicle/imu_ok', 10)
        self.theta_pub = self.create_publisher(Float32, '/vehicle/imu_theta_deg', 10)
        self.roll_pub = self.create_publisher(Float32, '/vehicle/imu_roll_deg', 10)
        self.pitch_pub = self.create_publisher(Float32, '/vehicle/imu_pitch_deg', 10)
        self.gz_pub = self.create_publisher(Float32, '/vehicle/imu_gz_dps', 10)

        self.ax_pub = self.create_publisher(Float32, '/vehicle/imu_ax_g', 10)
        self.ay_pub = self.create_publisher(Float32, '/vehicle/imu_ay_g', 10)
        self.az_pub = self.create_publisher(Float32, '/vehicle/imu_az_g', 10)

        # ROS subscriber for teleop/control commands
        self.cmd_sub = self.create_subscription(
            String,
            '/vehicle/cmd',
            self.cmd_callback,
            10
        )

        # Open Arduino serial
        try:
            self.ser = serial.Serial(
                self.port,
                self.baud,
                timeout=0.001,
                write_timeout=0.05
            )
            time.sleep(2.0)  # Arduino resets when serial opens
        except Exception as e:
            self.get_logger().error(f'Failed to open serial port {self.port}: {e}')
            raise

        self.get_logger().info(f'Connected to Arduino on {self.port} @ {self.baud}')
        self.get_logger().info('Listening to /vehicle/cmd and publishing vehicle states...')

        # Read serial at 100 Hz
        self.timer = self.create_timer(0.01, self.read_serial)

    def publish_string(self, pub, value):
        msg = String()
        msg.data = str(value)
        pub.publish(msg)

    def publish_int(self, pub, value):
        msg = Int32()
        msg.data = int(float(value))
        pub.publish(msg)

    def publish_float(self, pub, value):
        msg = Float32()
        msg.data = float(value)
        pub.publish(msg)

    def publish_bool(self, pub, value):
        msg = Bool()
        msg.data = bool(int(float(value)))
        pub.publish(msg)

    def cmd_callback(self, msg):
        cmd = msg.data.strip()

        if not cmd:
            return

        try:
            self.ser.write((cmd + '\n').encode('utf-8'))
            self.get_logger().info(f'Sent to Arduino: {cmd}')
        except Exception as e:
            self.get_logger().error(f'Failed to send command "{cmd}": {e}')

    def parse_state_line(self, line):
        """
        Expected Arduino line:
        STATE T=0 C=0 E=0 A=90 IMU=1 THETA=0.03 ROLL=-1.20 PITCH=0.45 GZ=0.02 AX=0.01 AY=-0.02 AZ=1.00
        """

        pairs = dict(re.findall(r'([A-Z_]+)=(-?\d+(?:\.\d+)?)', line))

        try:
            if 'T' in pairs:
                self.publish_int(self.target_cmd_pub, pairs['T'])

            if 'C' in pairs:
                self.publish_int(self.current_cmd_pub, pairs['C'])

            if 'E' in pairs:
                self.publish_int(self.encoder_pub, pairs['E'])

            if 'A' in pairs:
                self.publish_float(self.steering_angle_pub, pairs['A'])

            if 'IMU' in pairs:
                self.publish_bool(self.imu_ok_pub, pairs['IMU'])

            if 'THETA' in pairs:
                self.publish_float(self.theta_pub, pairs['THETA'])

            if 'ROLL' in pairs:
                self.publish_float(self.roll_pub, pairs['ROLL'])

            if 'PITCH' in pairs:
                self.publish_float(self.pitch_pub, pairs['PITCH'])

            if 'GZ' in pairs:
                self.publish_float(self.gz_pub, pairs['GZ'])

            if 'AX' in pairs:
                self.publish_float(self.ax_pub, pairs['AX'])

            if 'AY' in pairs:
                self.publish_float(self.ay_pub, pairs['AY'])

            if 'AZ' in pairs:
                self.publish_float(self.az_pub, pairs['AZ'])

        except Exception as e:
            self.get_logger().warn(f'Could not parse state line: {line} | Error: {e}')

    def read_serial(self):
        try:
            while self.ser.in_waiting > 0:
                line = self.ser.readline().decode('utf-8', errors='ignore').strip()

                if not line:
                    continue

                self.publish_string(self.raw_pub, line)

                if self.print_raw:
                    self.get_logger().info(f'Arduino: {line}')

                if line.startswith('STATE'):
                    self.parse_state_line(line)

        except Exception as e:
            self.get_logger().error(f'Serial read error: {e}')

    def close_serial(self):
        try:
            if self.ser and self.ser.is_open:
                self.ser.close()
                self.get_logger().info('Closed serial port')
        except Exception:
            pass


def main(args=None):
    rclpy.init(args=args)
    node = None

    try:
        node = VehicleInterfaceNode()
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    finally:
        if node is not None:
            node.close_serial()
            node.destroy_node()

        rclpy.shutdown()


if __name__ == '__main__':
    main()
