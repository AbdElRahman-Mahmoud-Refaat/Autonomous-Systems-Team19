#!/usr/bin/env python3

import sys
import time
import termios
import tty
import select

import rclpy
from rclpy.node import Node
import serial


MSG = """
Integrated Vehicle Teleop
-------------------------
Left Arrow   : servo 5 deg left
Right Arrow  : servo 5 deg right
Up Arrow     : motor accelerate forward
Down Arrow   : motor accelerate backward
Space / c    : center servo
s            : stop motor + clear state
z            : zero encoder only
q            : center servo + clear state + reset Arduino + quit
"""


class IntegratedVehicleTeleop(Node):
    def __init__(self):
        super().__init__('integrated_vehicle_teleop')

        self.declare_parameter('serial_port', '/dev/ttyACM0')
        self.declare_parameter('baud_rate', 115200)

        serial_port = self.get_parameter('serial_port').value
        baud_rate = int(self.get_parameter('baud_rate').value)

        self.ser = None

        try:
            self.ser = serial.Serial(serial_port, baud_rate, timeout=0.05)
            time.sleep(2.0)
            self.get_logger().info(
                f'Connected to Arduino on {serial_port} @ {baud_rate}'
            )
        except Exception as e:
            self.get_logger().error(f'Failed to open serial port: {e}')

        self.get_logger().info(MSG)

        self.create_timer(0.05, self.read_serial)

    def read_serial(self):
        if self.ser and self.ser.is_open:
            try:
                while self.ser.in_waiting > 0:
                    line = self.ser.readline().decode('utf-8', errors='ignore').strip()
                    if line:
                        self.get_logger().info(f'Arduino: {line}')
            except Exception as e:
                self.get_logger().error(f'Serial read error: {e}')

    def send_cmd(self, cmd: str):
        if self.ser and self.ser.is_open:
            try:
                self.ser.write((cmd + '\n').encode('utf-8'))
                self.get_logger().info(f'Sent -> {cmd}')
            except Exception as e:
                self.get_logger().error(f'Serial write error: {e}')
        else:
            self.get_logger().error('Serial port is not open')

    def close_serial(self):
        if self.ser and self.ser.is_open:
            self.ser.close()

    def process_key(self, key):
        if key == '\x1b[D':          # Left
            self.send_cmd('L')

        elif key == '\x1b[C':        # Right
            self.send_cmd('R')

        elif key == '\x1b[A':        # Up
            self.send_cmd('UP')

        elif key == '\x1b[B':        # Down
            self.send_cmd('DOWN')

        elif key == ' ' or key.lower() == 'c':
            self.send_cmd('CENTER')

        elif key.lower() == 's':
            self.send_cmd('CLEAR')

        elif key.lower() == 'z':
            self.send_cmd('ZEROENC')

        elif key.lower() == 'q':
            self.send_cmd('CENTER')
            time.sleep(0.15)
            self.send_cmd('CLEAR')
            time.sleep(0.15)
            self.send_cmd('RESET')
            time.sleep(0.20)
            raise KeyboardInterrupt


def get_key():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        rlist, _, _ = select.select([sys.stdin], [], [], 0.05)
        if rlist:
            ch1 = sys.stdin.read(1)
            if ch1 == '\x1b':
                ch2 = sys.stdin.read(1)
                ch3 = sys.stdin.read(1)
                return ch1 + ch2 + ch3
            return ch1
        return ''
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


def main(args=None):
    rclpy.init(args=args)
    node = IntegratedVehicleTeleop()

    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.0)
            key = get_key()
            if key:
                node.process_key(key)

    except KeyboardInterrupt:
        node.get_logger().info('Stopping integrated teleop...')

    finally:
        node.close_serial()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
