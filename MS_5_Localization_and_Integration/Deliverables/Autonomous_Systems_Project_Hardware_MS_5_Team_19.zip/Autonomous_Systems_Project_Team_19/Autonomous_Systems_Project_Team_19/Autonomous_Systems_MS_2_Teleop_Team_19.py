#!/usr/bin/env python3

import sys
import time
import termios
import tty
import select

import rclpy
from rclpy.node import Node

from std_msgs.msg import String


MSG = """
ROS 2 Vehicle Teleop with IMU Support
-------------------------------------
Hold Up Arrow      : accelerate forward
Hold Down Arrow    : accelerate backward
Left Arrow         : steer left
Right Arrow        : steer right
c                  : center steering
s                  : stop + center + zero encoder + zero IMU
z                  : zero encoder only
i                  : zero IMU heading only
q                  : stop + reset Arduino + quit
"""


class VehicleTeleopNode(Node):
    def __init__(self):
        super().__init__('Autonomous_Systems_MS_2_Teleop_Team_19')

        self.cmd_pub = self.create_publisher(String, '/vehicle/cmd', 10)

        self.raw_sub = self.create_subscription(
            String,
            '/vehicle/state_raw',
            self.raw_callback,
            10
        )

        self.last_print_time = 0.0

        self.get_logger().info('Teleop node started')
        print(MSG)

    def send_cmd(self, cmd):
        msg = String()
        msg.data = cmd
        self.cmd_pub.publish(msg)
        print(f'\rSent: {cmd}                     ')

    def raw_callback(self, msg):
        # Print Arduino feedback, but not too aggressively
        now = time.time()

        if now - self.last_print_time >= 0.25:
            self.last_print_time = now
            print(f'\rArduino: {msg.data}                    ')


def get_key(timeout=0.02):
    rlist, _, _ = select.select([sys.stdin], [], [], timeout)

    if rlist:
        ch1 = sys.stdin.read(1)

        if ch1 == '\x1b':
            ch2 = sys.stdin.read(1)
            ch3 = sys.stdin.read(1)
            return ch1 + ch2 + ch3

        return ch1

    return ''


def spin_for_short_time(node, duration=0.05):
    end_time = time.time() + duration

    while time.time() < end_time and rclpy.ok():
        rclpy.spin_once(node, timeout_sec=0.005)


def main(args=None):
    rclpy.init(args=args)

    node = VehicleTeleopNode()

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)

    try:
        tty.setraw(fd)

        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.001)

            key = get_key(timeout=0.02)

            if key == '\x1b[A':          # Up arrow
                node.send_cmd('UP')

            elif key == '\x1b[B':        # Down arrow
                node.send_cmd('DOWN')

            elif key == '\x1b[D':        # Left arrow
                node.send_cmd('L')

            elif key == '\x1b[C':        # Right arrow
                node.send_cmd('R')

            elif key.lower() == 'c':
                node.send_cmd('CENTER')

            elif key.lower() == 's':
                node.send_cmd('CENTER')
                spin_for_short_time(node, 0.05)
                node.send_cmd('CLEAR')

            elif key.lower() == 'z':
                node.send_cmd('ZEROENC')

            elif key.lower() == 'i':
                node.send_cmd('ZEROIMU')

            elif key.lower() == 'q':
                node.send_cmd('CENTER')
                spin_for_short_time(node, 0.05)

                node.send_cmd('CLEAR')
                spin_for_short_time(node, 0.10)

                node.send_cmd('RESET')
                spin_for_short_time(node, 0.20)

                break

    except KeyboardInterrupt:
        node.send_cmd('CENTER')
        spin_for_short_time(node, 0.05)
        node.send_cmd('CLEAR')

    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

        node.destroy_node()
        rclpy.shutdown()

        print('\nTeleop closed')


if __name__ == '__main__':
    main()
