Scenario 2 Track 02 - Existing Arduino Protocol

Copy this folder into:
~/ros2_ws/src/Autonomous_Systems_Project_Team_19/

Then add this to setup.py console_scripts:
'Autonomous_Systems_MS_4_Scenario2_Team_19 = Autonomous_Systems_Project_Team_19.scenario2_track2_existing_arduino_team19:main',

This version uses the Arduino STATE protocol:
STATE T=... C=... E=... A=... IMU=... THETA=... ROLL=... PITCH=... GZ=... AX=... AY=... AZ=...

And sends:
UP, DOWN, L, R, CENTER, CLEAR, ZEROENC, ZEROIMU
