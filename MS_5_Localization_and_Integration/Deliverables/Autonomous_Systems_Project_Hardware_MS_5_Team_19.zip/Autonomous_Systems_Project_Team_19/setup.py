from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'Autonomous_Systems_Project_Team_19'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='team19',
    maintainer_email='team19@example.com',
    description='Autonomous Systems Project Team 19 package',
    license='Apache License 2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'Autonomous_Systems_MS_2_OLR_Team_19 = Autonomous_Systems_Project_Team_19.Autonomous_Systems_MS_2_OLR_Team_19:main',
            'Autonomous_Systems_MS_2_Teleop_Team_19 = Autonomous_Systems_Project_Team_19.Autonomous_Systems_MS_2_Teleop_Team_19:main',
            'vehicle_interface_node = Autonomous_Systems_Project_Team_19.vehicle_interface_node:main',
            'Validation_Printing_Node_Team_19 = Autonomous_Systems_Project_Team_19.Validation_Printing_Node_Team_19:main',
            'rpi_all_processing_teleop_team19 = Autonomous_Systems_Project_Team_19.rpi_all_processing_teleop_team19:main',
            'scenario1_straight_4m_team19 = Autonomous_Systems_Project_Team_19.scenario1_straight_4m_team19:main',
            'Autonomous_Systems_MS_4_Track2_Stanley_Team_19 = Autonomous_Systems_Project_Team_19.scenario2_track2_stanley_team19_FIXED:main',
            'Autonomous_Systems_MS_4_Scenario2_Team_19 = Autonomous_Systems_Project_Team_19.scenario2_track2_existing_arduino_team19:main',        ],
    },
)
