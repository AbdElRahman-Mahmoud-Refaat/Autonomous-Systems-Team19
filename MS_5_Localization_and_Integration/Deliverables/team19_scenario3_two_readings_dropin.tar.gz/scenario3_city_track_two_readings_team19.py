#!/usr/bin/env python3
"""
Team 19 - Scenario 3 City Track Full Lap
Two-readings-based hardware controller for the existing Arduino low-level code.

Arduino interface expected:
  Arduino -> Pi:
    S,time_ms,encoder,ax,ay,az,gx,gy,gz,pwm,servo_us,imu_ok
  Pi -> Arduino:
    C,<signed_pwm>,<servo_us>
    ZERO
    ZEROIMU

Main idea:
  - Uses the TWO teleop readings provided by AbdElRahman.
  - Ignores the accidental reset tails in both readings.
  - Builds a smoothed clockwise reference path matching the orange-arrow start.
  - Follows one clockwise lap using encoder odometry + IMU heading + Stanley control.
"""

import math
import sys
import time
import select
import termios
import tty
from typing import Dict, List, Optional, Tuple

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, String, Bool

try:
    import serial
except ImportError:
    serial = None


class KeyboardReader:
    def __init__(self):
        self.old_settings = None

    def __enter__(self):
        self.old_settings = termios.tcgetattr(sys.stdin)
        tty.setcbreak(sys.stdin.fileno())
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if self.old_settings is not None:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.old_settings)

    def get_key(self) -> str:
        if select.select([sys.stdin], [], [], 0.0)[0]:
            return sys.stdin.read(1)
        return ''


class Scenario3CityTrackGeometry(Node):
    def __init__(self):
        super().__init__('scenario3_city_track_two_readings_team19')

        # ============================================================
        # Serial parameters
        # ============================================================
        self.declare_parameter('port', '/dev/ttyACM0')
        self.declare_parameter('baud', 9600)
        self.declare_parameter('print_raw', False)

        self.port = str(self.get_parameter('port').value)
        self.baud = int(self.get_parameter('baud').value)
        self.print_raw = bool(self.get_parameter('print_raw').value)

        # ============================================================
        # Hardware / localization parameters
        # ============================================================
        self.declare_parameter('ppr', 1085.0)
        self.declare_parameter('wheel_diameter_cm', 6.5)
        self.declare_parameter('encoder_sign', 1.0)
        self.declare_parameter('theta_sign', 1.0)
        self.declare_parameter('calibration_samples', 40)

        self.ppr = float(self.get_parameter('ppr').value)
        self.wheel_diameter_cm = float(self.get_parameter('wheel_diameter_cm').value)
        self.wheel_circumference_m = math.pi * self.wheel_diameter_cm / 100.0
        self.encoder_sign = float(self.get_parameter('encoder_sign').value)
        self.theta_sign = float(self.get_parameter('theta_sign').value)
        self.calibration_samples = int(self.get_parameter('calibration_samples').value)

        # ============================================================
        # City track geometry
        # Coordinates are relative to your chosen start point:
        #   start = top straight, heading to the right
        #   +x = right, -y = down
        # Defaults are based on the 5 m x 4 m outer map and 0.5 m road width.
        # ============================================================
        self.declare_parameter('centerline_width_m', 4.50)
        self.declare_parameter('centerline_height_m', 3.30)
        self.declare_parameter('corner_radius_m', 0.55)
        self.declare_parameter('waypoint_spacing_m', 0.04)

        self.centerline_width_m = float(self.get_parameter('centerline_width_m').value)
        self.centerline_height_m = float(self.get_parameter('centerline_height_m').value)
        self.corner_radius_m = float(self.get_parameter('corner_radius_m').value)
        self.waypoint_spacing_m = float(self.get_parameter('waypoint_spacing_m').value)

        # ============================================================
        # Motion parameters
        # ============================================================
        self.declare_parameter('straight_speed_mps', 0.16)
        self.declare_parameter('curve_speed_mps', 0.10)
        self.declare_parameter('final_speed_mps', 0.07)
        self.declare_parameter('slowdown_before_curve_m', 0.25)
        self.declare_parameter('stop_tolerance_m', 0.08)

        self.straight_speed_mps = float(self.get_parameter('straight_speed_mps').value)
        self.curve_speed_mps = float(self.get_parameter('curve_speed_mps').value)
        self.final_speed_mps = float(self.get_parameter('final_speed_mps').value)
        self.slowdown_before_curve_m = float(self.get_parameter('slowdown_before_curve_m').value)
        self.stop_tolerance_m = float(self.get_parameter('stop_tolerance_m').value)

        # ============================================================
        # Longitudinal PWM controller on Raspberry Pi
        # ============================================================
        self.declare_parameter('min_move_cmd', 75.0)
        self.declare_parameter('max_motor_cmd', 135.0)
        self.declare_parameter('speed_kp_pwm_per_mps', 260.0)
        self.declare_parameter('speed_ki_pwm_per_m', 35.0)
        self.declare_parameter('max_accel_pwm_per_cycle', 4.0)
        self.declare_parameter('max_speed_for_ff_mps', 0.24)

        self.min_move_cmd = float(self.get_parameter('min_move_cmd').value)
        self.max_motor_cmd = float(self.get_parameter('max_motor_cmd').value)
        self.speed_kp = float(self.get_parameter('speed_kp_pwm_per_mps').value)
        self.speed_ki = float(self.get_parameter('speed_ki_pwm_per_m').value)
        self.max_accel_pwm_per_cycle = float(self.get_parameter('max_accel_pwm_per_cycle').value)
        self.max_speed_for_ff_mps = float(self.get_parameter('max_speed_for_ff_mps').value)

        # ============================================================
        # Stanley lateral controller
        # Important for your car:
        #   command steer_deg is right-positive, because your teleop showed
        #   positive steer -> servo > 1500 -> clockwise/right turn.
        # ============================================================
        self.declare_parameter('k_stanley', 0.75)
        self.declare_parameter('lookahead_m', 0.18)
        self.declare_parameter('max_steer_deg', 25.0)
        self.declare_parameter('us_per_deg', 8.0)
        self.declare_parameter('steer_sign', 1.0)
        self.declare_parameter('cte_sign', 1.0)
        self.declare_parameter('heading_gain', 1.0)
        self.declare_parameter('cte_gain_scale', 1.0)

        self.k_stanley = float(self.get_parameter('k_stanley').value)
        self.lookahead_m = float(self.get_parameter('lookahead_m').value)
        self.max_steer_deg = float(self.get_parameter('max_steer_deg').value)
        self.us_per_deg = float(self.get_parameter('us_per_deg').value)
        self.steer_sign = float(self.get_parameter('steer_sign').value)
        self.cte_sign = float(self.get_parameter('cte_sign').value)
        self.heading_gain = float(self.get_parameter('heading_gain').value)
        self.cte_gain_scale = float(self.get_parameter('cte_gain_scale').value)

        self.servo_center_us = 1500
        self.servo_min_us = 1100
        self.servo_max_us = 1900

        # ============================================================
        # ROS publishers for checking / plotting
        # ============================================================
        self.mode_pub = self.create_publisher(String, '/scenario3/mode', 10)
        self.raw_pub = self.create_publisher(String, '/vehicle/state_raw', 10)
        self.imu_ok_pub = self.create_publisher(Bool, '/vehicle/imu_ok', 10)
        self.x_pub = self.create_publisher(Float32, '/vehicle/x_m', 10)
        self.y_pub = self.create_publisher(Float32, '/vehicle/y_m', 10)
        self.theta_pub = self.create_publisher(Float32, '/vehicle/imu_theta_deg', 10)
        self.speed_pub = self.create_publisher(Float32, '/vehicle/speed_mps', 10)
        self.progress_pub = self.create_publisher(Float32, '/scenario3/progress_m', 10)
        self.cte_pub = self.create_publisher(Float32, '/scenario3/cte_m', 10)
        self.des_speed_pub = self.create_publisher(Float32, '/scenario3/desired_speed_mps', 10)
        self.steer_pub = self.create_publisher(Float32, '/scenario3/steer_deg', 10)

        # ============================================================
        # Serial connection
        # ============================================================
        if serial is None:
            raise RuntimeError('pyserial is missing. Install with: pip3 install pyserial')

        self.ser = serial.Serial(self.port, self.baud, timeout=0.0, write_timeout=0.02)
        time.sleep(2.0)
        self.ser.reset_input_buffer()
        self.ser.reset_output_buffer()
        self.rx_buffer = ''

        # ============================================================
        # State variables
        # ============================================================
        self.mode = 'CALIBRATING'
        self.auto_enabled = False
        self.finished = False
        self.quit_requested = False

        self.imu_ok = False
        self.gz_offset_sum = 0.0
        self.gz_offset_count = 0
        self.gz_offset = 0.0

        self.prev_time_ms: Optional[int] = None
        self.prev_encoder: Optional[int] = None
        self.encoder_zero_reference: Optional[int] = None

        self.x = 0.0
        self.y = 0.0
        self.theta_deg = 0.0
        self.theta_rad = 0.0
        self.distance_m = 0.0
        self.v_mps = 0.0
        self.v_filt_mps = 0.0

        self.desired_speed_mps = 0.0
        self.pwm_cmd = 0.0
        self.speed_integral = 0.0
        self.steer_deg_cmd = 0.0
        self.servo_us_cmd = self.servo_center_us

        self.closest_idx = 0
        self.last_progress_m = 0.0
        self.last_print_time = 0.0

        # Build the actual path that matches your drawing
        self.path = self.build_city_path()
        self.path_length_m = self.path[-1]['s'] if self.path else 0.0
        self.path_spacing_m = self.path_length_m / max(1, len(self.path) - 1)
        self.lookahead_points = max(1, int(self.lookahead_m / max(self.path_spacing_m, 1e-3)))
        self.search_window_points = max(18, int(1.20 / max(self.path_spacing_m, 1e-3)))

        # Timers
        self.timer = self.create_timer(0.02, self.loop)  # 50 Hz

        self.get_logger().info(f'Scenario 3 TWO-READINGS node started on {self.port} @ {self.baud}')
        self.get_logger().info(
            f'Generated two-readings clockwise path: {len(self.path)} points, length={self.path_length_m:.2f} m'
        )
        self.print_help()

    # ============================================================
    # Helpers
    # ============================================================
    @staticmethod
    def clamp(value: float, lo: float, hi: float) -> float:
        return max(lo, min(hi, value))

    @staticmethod
    def normalize_rad(a: float) -> float:
        while a > math.pi:
            a -= 2.0 * math.pi
        while a < -math.pi:
            a += 2.0 * math.pi
        return a

    @staticmethod
    def normalize_deg(a: float) -> float:
        while a > 180.0:
            a -= 360.0
        while a < -180.0:
            a += 360.0
        return a

    def print_help(self):
        print('\n' + '=' * 68)
        print('TEAM 19 - SCENARIO 3 CITY TRACK - TWO READINGS FOLLOWER')
        print('=' * 68)
        print('Path used by this code:')
        print('  Start on TOP STRAIGHT, heading RIGHT.')
        print('  Then clockwise: top straight -> right curve -> right side')
        print('  -> bottom curve -> bottom straight -> left curve -> left side')
        print('  -> top-left curve -> return to the same start point.')
        print('')
        print('Controls:')
        print('  z : zero encoder + IMU heading + x/y/progress')
        print('  a : start autonomous full lap')
        print('  s : emergency stop')
        print('  c : center steering')
        print('  i : zero IMU heading only')
        print('  q : stop and quit')
        print('')
        print('Start sequence:')
        print('  1) Put car on the orange-arrow start point, facing RIGHT.')
        print('  2) Keep it still until mode=WAITING.')
        print('  3) Press z.')
        print('  4) Press a.')
        print('=' * 68 + '\n')

    # ============================================================
    # Path generation
    # ============================================================
    def add_point(self, pts: List[Tuple[float, float]], x: float, y: float):
        if not pts or math.hypot(x - pts[-1][0], y - pts[-1][1]) > 1e-6:
            pts.append((x, y))

    def add_line(self, pts: List[Tuple[float, float]], x0: float, y0: float, x1: float, y1: float):
        length = math.hypot(x1 - x0, y1 - y0)
        n = max(1, int(math.ceil(length / self.waypoint_spacing_m)))
        for i in range(n + 1):
            t = i / n
            self.add_point(pts, x0 + t * (x1 - x0), y0 + t * (y1 - y0))

    def add_arc(self, pts: List[Tuple[float, float]], cx: float, cy: float, r: float, a0: float, a1: float):
        length = abs(a1 - a0) * r
        n = max(4, int(math.ceil(length / self.waypoint_spacing_m)))
        for i in range(n + 1):
            t = i / n
            a = a0 + t * (a1 - a0)
            self.add_point(pts, cx + r * math.cos(a), cy + r * math.sin(a))

    def build_city_path(self) -> List[Dict[str, float]]:
        """
        Build Scenario 3 path from the TWO teleop readings you provided.

        How these points were made:
          - Reading 1: 143 valid logged points before its accidental reset.
          - Reading 2: 247 valid logged points before its accidental reset.
          - The reset-only bad tails were ignored.
          - Both readings were re-sampled by normalized lap progress, combined,
            lightly smoothed, and forced to close at the start point.

        This keeps the real driven clockwise route:
          top start -> right side -> bottom -> left side -> back to start.
        """
        raw_pts: List[Tuple[float, float]] = [
            (+0.000, +0.000),
            (+0.086, -0.002),
            (+0.173, -0.004),
            (+0.259, -0.008),
            (+0.346, -0.012),
            (+0.432, -0.017),
            (+0.518, -0.022),
            (+0.605, -0.028),
            (+0.691, -0.033),
            (+0.777, -0.039),
            (+0.863, -0.044),
            (+0.949, -0.048),
            (+1.036, -0.052),
            (+1.122, -0.056),
            (+1.208, -0.060),
            (+1.295, -0.064),
            (+1.381, -0.068),
            (+1.467, -0.073),
            (+1.553, -0.080),
            (+1.639, -0.089),
            (+1.723, -0.102),
            (+1.807, -0.118),
            (+1.889, -0.140),
            (+1.969, -0.169),
            (+2.045, -0.206),
            (+2.118, -0.250),
            (+2.185, -0.301),
            (+2.248, -0.358),
            (+2.305, -0.421),
            (+2.354, -0.489),
            (+2.396, -0.563),
            (+2.431, -0.640),
            (+2.458, -0.721),
            (+2.478, -0.804),
            (+2.492, -0.889),
            (+2.500, -0.974),
            (+2.504, -1.060),
            (+2.501, -1.146),
            (+2.493, -1.232),
            (+2.480, -1.317),
            (+2.465, -1.401),
            (+2.451, -1.486),
            (+2.436, -1.571),
            (+2.423, -1.656),
            (+2.411, -1.742),
            (+2.400, -1.827),
            (+2.390, -1.913),
            (+2.382, -1.999),
            (+2.375, -2.086),
            (+2.369, -2.172),
            (+2.364, -2.258),
            (+2.358, -2.344),
            (+2.351, -2.430),
            (+2.342, -2.515),
            (+2.328, -2.599),
            (+2.308, -2.682),
            (+2.283, -2.762),
            (+2.250, -2.840),
            (+2.211, -2.914),
            (+2.164, -2.984),
            (+2.111, -3.048),
            (+2.051, -3.107),
            (+1.985, -3.159),
            (+1.915, -3.204),
            (+1.840, -3.241),
            (+1.761, -3.271),
            (+1.680, -3.294),
            (+1.597, -3.310),
            (+1.512, -3.321),
            (+1.426, -3.327),
            (+1.340, -3.327),
            (+1.254, -3.324),
            (+1.168, -3.318),
            (+1.082, -3.310),
            (+0.996, -3.301),
            (+0.910, -3.292),
            (+0.825, -3.282),
            (+0.739, -3.271),
            (+0.654, -3.259),
            (+0.568, -3.249),
            (+0.483, -3.240),
            (+0.396, -3.234),
            (+0.310, -3.232),
            (+0.224, -3.233),
            (+0.137, -3.236),
            (+0.051, -3.241),
            (-0.035, -3.247),
            (-0.122, -3.253),
            (-0.208, -3.258),
            (-0.294, -3.260),
            (-0.381, -3.261),
            (-0.467, -3.258),
            (-0.553, -3.252),
            (-0.639, -3.242),
            (-0.724, -3.227),
            (-0.808, -3.206),
            (-0.890, -3.180),
            (-0.970, -3.150),
            (-1.047, -3.113),
            (-1.122, -3.072),
            (-1.192, -3.024),
            (-1.259, -2.970),
            (-1.321, -2.911),
            (-1.379, -2.847),
            (-1.431, -2.779),
            (-1.477, -2.706),
            (-1.516, -2.630),
            (-1.548, -2.550),
            (-1.573, -2.467),
            (-1.593, -2.383),
            (-1.608, -2.298),
            (-1.620, -2.212),
            (-1.629, -2.126),
            (-1.636, -2.040),
            (-1.640, -1.954),
            (-1.642, -1.868),
            (-1.642, -1.781),
            (-1.639, -1.695),
            (-1.635, -1.609),
            (-1.628, -1.523),
            (-1.619, -1.437),
            (-1.609, -1.351),
            (-1.597, -1.266),
            (-1.584, -1.180),
            (-1.570, -1.095),
            (-1.556, -1.010),
            (-1.541, -0.925),
            (-1.525, -0.840),
            (-1.506, -0.755),
            (-1.485, -0.672),
            (-1.460, -0.591),
            (-1.430, -0.511),
            (-1.392, -0.436),
            (-1.347, -0.364),
            (-1.295, -0.298),
            (-1.237, -0.237),
            (-1.173, -0.182),
            (-1.103, -0.134),
            (-1.030, -0.092),
            (-0.953, -0.057),
            (-0.872, -0.028),
            (-0.790, -0.004),
            (-0.706, +0.013),
            (-0.620, +0.025),
            (-0.534, +0.032),
            (-0.448, +0.032),
            (-0.362, +0.027),
            (-0.270, +0.018),
            (-0.152, +0.009),
            (+0.000, +0.000),
        ]

        # Convert raw x/y points to path dictionaries with yaw, cumulative s,
        # and automatic section labels from local heading change.
        path: List[Dict[str, float]] = []
        s = 0.0
        for i, (x, y) in enumerate(raw_pts):
            if i > 0:
                px, py = raw_pts[i - 1]
                s += math.hypot(x - px, y - py)

            if i < len(raw_pts) - 1:
                nx, ny = raw_pts[i + 1]
                yaw = math.atan2(ny - y, nx - x)
            else:
                px, py = raw_pts[i - 1]
                yaw = math.atan2(y - py, x - px)

            section = 'straight'
            if 1 <= i < len(raw_pts) - 1:
                x0, y0 = raw_pts[i - 1]
                x1, y1 = raw_pts[i]
                x2, y2 = raw_pts[i + 1]
                yaw1 = math.atan2(y1 - y0, x1 - x0)
                yaw2 = math.atan2(y2 - y1, x2 - x1)
                dyaw = abs(self.normalize_rad(yaw2 - yaw1))

                # Reading-derived thresholds. This is intentionally gentle
                # because the recorded human trail has small steering noise.
                if dyaw > math.radians(4.0):
                    section = 'curve'
                elif dyaw > math.radians(1.0):
                    section = 'approach'

            path.append({'x': x, 'y': y, 'yaw': yaw, 's': s, 'section': section})

        # Slow down before/after curve sections.
        curve_indices = [i for i, p in enumerate(path) if p['section'] == 'curve']
        if curve_indices:
            for i, p in enumerate(path):
                for ci in curve_indices:
                    if abs(path[ci]['s'] - p['s']) <= self.slowdown_before_curve_m:
                        if p['section'] == 'straight':
                            p['section'] = 'approach'
                        break

        return path

    # ============================================================
    # Serial
    # ============================================================
    def send_line(self, line: str):
        try:
            self.ser.write((line.strip() + '\n').encode('utf-8'))
        except Exception as e:
            self.get_logger().warn(f'Serial write failed: {e}')

    def send_command(self, pwm: float, servo_us: float):
        pwm_i = int(round(self.clamp(pwm, -255, 255)))
        servo_i = int(round(self.clamp(servo_us, self.servo_min_us, self.servo_max_us)))
        self.send_line(f'C,{pwm_i},{servo_i}')

    def stop_car(self):
        self.pwm_cmd = 0.0
        self.desired_speed_mps = 0.0
        self.speed_integral = 0.0
        self.send_command(0, self.servo_center_us)

    def center_steering(self):
        self.steer_deg_cmd = 0.0
        self.servo_us_cmd = self.servo_center_us
        self.send_command(0 if not self.auto_enabled else self.pwm_cmd, self.servo_center_us)

    def read_serial_packets(self) -> List[str]:
        lines = []
        try:
            n = self.ser.in_waiting
            if n <= 0:
                return lines
            data = self.ser.read(n).decode('utf-8', errors='ignore')
            if not data:
                return lines
            self.rx_buffer += data

            # Keep memory bounded in case of corrupted input.
            if len(self.rx_buffer) > 5000:
                idx = self.rx_buffer.rfind('S,')
                self.rx_buffer = self.rx_buffer[idx:] if idx >= 0 else ''

            while '\n' in self.rx_buffer:
                line, self.rx_buffer = self.rx_buffer.split('\n', 1)
                line = line.strip().replace('\r', '')
                if line:
                    lines.append(line)
        except Exception as e:
            self.get_logger().warn(f'Serial read error: {e}')
        return lines

    def parse_state_line(self, line: str) -> Optional[Dict[str, int]]:
        if self.print_raw:
            print(line)

        msg = String()
        msg.data = line
        self.raw_pub.publish(msg)

        if not line.startswith('S,'):
            return None

        parts = line.split(',')
        if len(parts) != 12:
            return None

        try:
            return {
                'time_ms': int(parts[1]),
                'encoder': int(parts[2]),
                'ax': int(parts[3]),
                'ay': int(parts[4]),
                'az': int(parts[5]),
                'gx': int(parts[6]),
                'gy': int(parts[7]),
                'gz': int(parts[8]),
                'arduino_pwm': int(parts[9]),
                'arduino_servo': int(parts[10]),
                'imu_ok': int(parts[11]),
            }
        except ValueError:
            return None

    # ============================================================
    # Zero / calibration / localization
    # ============================================================
    def zero_all(self):
        self.stop_car()
        time.sleep(0.04)
        self.send_line('ZERO')
        time.sleep(0.04)
        self.send_line('ZEROIMU')

        self.x = 0.0
        self.y = 0.0
        self.theta_deg = 0.0
        self.theta_rad = 0.0
        self.distance_m = 0.0
        self.v_mps = 0.0
        self.v_filt_mps = 0.0
        self.prev_time_ms = None
        self.prev_encoder = None
        self.encoder_zero_reference = None
        self.closest_idx = 0
        self.last_progress_m = 0.0
        self.pwm_cmd = 0.0
        self.speed_integral = 0.0
        self.finished = False
        self.auto_enabled = False
        self.mode = 'WAITING' if self.gz_offset_count >= self.calibration_samples else 'CALIBRATING'
        self.get_logger().info('Zeroed encoder, IMU heading, x, y, distance, and path progress.')

    def zero_imu_only(self):
        self.theta_deg = 0.0
        self.theta_rad = 0.0
        self.send_line('ZEROIMU')
        self.get_logger().info('Zeroed IMU heading only.')

    def update_calibration(self, state: Dict[str, int]):
        if state['imu_ok'] != 1:
            return

        gz_dps = state['gz'] / 131.0
        self.gz_offset_sum += gz_dps
        self.gz_offset_count += 1

        if self.gz_offset_count >= self.calibration_samples:
            self.gz_offset = self.gz_offset_sum / max(1, self.gz_offset_count)
            self.mode = 'WAITING'
            self.get_logger().info(f'Gyro calibration done. gz_offset={self.gz_offset:.4f} deg/s')
            self.get_logger().info('Put car at the orange-arrow start, press z, then press a.')

    def update_localization(self, state: Dict[str, int]):
        time_ms = state['time_ms']
        encoder = state['encoder']

        if self.prev_time_ms is None or self.prev_encoder is None:
            self.prev_time_ms = time_ms
            self.prev_encoder = encoder
            self.encoder_zero_reference = encoder
            return

        dt = (time_ms - self.prev_time_ms) / 1000.0
        if dt <= 0.0 or dt > 0.5:
            self.prev_time_ms = time_ms
            self.prev_encoder = encoder
            return

        delta_counts = (encoder - self.prev_encoder) * self.encoder_sign
        self.prev_time_ms = time_ms
        self.prev_encoder = encoder

        ds = (delta_counts / self.ppr) * self.wheel_circumference_m
        self.distance_m += ds
        self.v_mps = ds / dt
        self.v_filt_mps = 0.75 * self.v_filt_mps + 0.25 * self.v_mps

        # Gyro Z integration. MPU6050 default sensitivity: 131 LSB/(deg/s).
        gz_dps = (state['gz'] / 131.0 - self.gz_offset) * self.theta_sign
        self.theta_deg = self.normalize_deg(self.theta_deg + gz_dps * dt)
        self.theta_rad = math.radians(self.theta_deg)

        # Odometry in the same frame as the generated path.
        self.x += ds * math.cos(self.theta_rad)
        self.y += ds * math.sin(self.theta_rad)

    # ============================================================
    # Path tracking
    # ============================================================
    def find_path_target(self) -> Tuple[Dict[str, float], Dict[str, float], float, float, int]:
        # Search only forward to avoid jumping to the final point, which is also near the start.
        start = max(0, self.closest_idx - 4)
        end = min(len(self.path) - 1, self.closest_idx + self.search_window_points)

        best_i = self.closest_idx
        best_d2 = float('inf')
        for i in range(start, end + 1):
            p = self.path[i]
            d2 = (self.x - p['x']) ** 2 + (self.y - p['y']) ** 2
            if d2 < best_d2:
                best_d2 = d2
                best_i = i

        # Progress should not go backwards except by a tiny amount.
        self.closest_idx = max(self.closest_idx, best_i)

        look_i = min(len(self.path) - 1, self.closest_idx + self.lookahead_points)
        closest = self.path[self.closest_idx]
        target = self.path[look_i]

        # Signed cross-track error: positive means path is to the left of the vehicle
        # in mathematical steering convention. Later it is converted to right-positive servo command.
        yaw = closest['yaw']
        tx = math.cos(yaw)
        ty = math.sin(yaw)
        ex = closest['x'] - self.x
        ey = closest['y'] - self.y
        cte = (tx * ey - ty * ex) * self.cte_sign

        progress = closest['s']
        remaining = max(0.0, self.path_length_m - progress)
        self.last_progress_m = progress
        return closest, target, cte, remaining, self.closest_idx

    def desired_speed_from_section(self, closest: Dict[str, float], remaining: float) -> float:
        if remaining < 0.45:
            return self.final_speed_mps
        if closest['section'] in ('curve', 'approach'):
            return self.curve_speed_mps
        return self.straight_speed_mps

    def speed_to_pwm(self, desired_speed: float) -> float:
        if desired_speed <= 0.001:
            self.speed_integral = 0.0
            return 0.0

        v = max(0.0, self.v_filt_mps)
        error = desired_speed - v
        self.speed_integral = self.clamp(self.speed_integral + error * 0.02, -0.30, 0.30)

        ff_ratio = self.clamp(desired_speed / max(0.05, self.max_speed_for_ff_mps), 0.0, 1.0)
        pwm_ff = self.min_move_cmd + ff_ratio * (self.max_motor_cmd - self.min_move_cmd)
        pwm_raw = pwm_ff + self.speed_kp * error + self.speed_ki * self.speed_integral
        pwm_raw = self.clamp(pwm_raw, self.min_move_cmd, self.max_motor_cmd)

        # Smooth the PWM to remove jerks.
        dp = self.clamp(pwm_raw - self.pwm_cmd, -self.max_accel_pwm_per_cycle, self.max_accel_pwm_per_cycle)
        return self.pwm_cmd + dp

    def compute_control(self):
        closest, target, cte, remaining, idx = self.find_path_target()

        # Stop after completing the full planned lap.
        if remaining <= self.stop_tolerance_m or idx >= len(self.path) - 3:
            self.finished = True
            self.auto_enabled = False
            self.mode = 'FINISHED'
            self.stop_car()
            self.get_logger().info('Scenario 3 full lap finished. Car stopped.')
            return

        self.desired_speed_mps = self.desired_speed_from_section(closest, remaining)

        desired_yaw = target['yaw']
        heading_error = self.normalize_rad(desired_yaw - self.theta_rad)

        # Stanley controller in mathematical sign convention.
        v_for_control = max(abs(self.v_filt_mps), 0.05)
        steer_math_rad = (
            self.heading_gain * heading_error
            + math.atan2(self.k_stanley * self.cte_gain_scale * cte, v_for_control)
        )
        steer_math_deg = math.degrees(steer_math_rad)

        # Convert to your car convention: right turn is positive command.
        steer_right_positive_deg = -steer_math_deg
        steer_right_positive_deg = self.clamp(
            steer_right_positive_deg, -self.max_steer_deg, self.max_steer_deg
        )

        self.steer_deg_cmd = steer_right_positive_deg
        self.servo_us_cmd = self.servo_center_us + self.steer_sign * self.us_per_deg * self.steer_deg_cmd
        self.servo_us_cmd = self.clamp(self.servo_us_cmd, self.servo_min_us, self.servo_max_us)

        self.pwm_cmd = self.speed_to_pwm(self.desired_speed_mps)
        self.send_command(self.pwm_cmd, self.servo_us_cmd)

        # Publish useful values for graphs.
        self.publish_float(self.cte_pub, cte)
        self.publish_float(self.des_speed_pub, self.desired_speed_mps)
        self.publish_float(self.steer_pub, self.steer_deg_cmd)

    # ============================================================
    # Keyboard
    # ============================================================
    def handle_key(self, key: str):
        if not key:
            return
        k = key.lower()

        if k == 'z':
            self.zero_all()
        elif k == 'i':
            self.zero_imu_only()
        elif k == 'c':
            self.center_steering()
            self.get_logger().info('Steering centered.')
        elif k == 's':
            self.auto_enabled = False
            self.mode = 'STOPPED'
            self.stop_car()
            self.get_logger().warn('Emergency stop.')
        elif k == 'a':
            if self.mode == 'CALIBRATING':
                self.get_logger().warn('Still calibrating. Wait for mode=WAITING first.')
                return
            self.closest_idx = 0
            self.last_progress_m = 0.0
            self.finished = False
            self.auto_enabled = True
            self.mode = 'AUTO'
            self.get_logger().info('Scenario 3 two-readings full lap started.')
        elif k == 'q':
            self.quit_requested = True
            self.auto_enabled = False
            self.stop_car()
            self.get_logger().warn('Quit requested.')

    # ============================================================
    # ROS publishing / dashboard
    # ============================================================
    def publish_float(self, pub, value: float):
        msg = Float32()
        msg.data = float(value)
        pub.publish(msg)

    def publish_basic_topics(self):
        mode_msg = String()
        mode_msg.data = self.mode
        self.mode_pub.publish(mode_msg)

        imu_msg = Bool()
        imu_msg.data = bool(self.imu_ok)
        self.imu_ok_pub.publish(imu_msg)

        self.publish_float(self.x_pub, self.x)
        self.publish_float(self.y_pub, self.y)
        self.publish_float(self.theta_pub, self.theta_deg)
        self.publish_float(self.speed_pub, self.v_filt_mps)
        self.publish_float(self.progress_pub, self.last_progress_m)

    def print_dashboard(self):
        now = time.time()
        if now - self.last_print_time < 0.25:
            return
        self.last_print_time = now
        remaining = max(0.0, self.path_length_m - self.last_progress_m)
        print(
            f'\rmode={self.mode:<11} | '
            f'x={self.x:+5.2f} y={self.y:+5.2f} theta={self.theta_deg:+6.1f}deg | '
            f'v={self.v_filt_mps:+.2f}/{self.desired_speed_mps:.2f} m/s | '
            f'prog={self.last_progress_m:5.2f}/{self.path_length_m:5.2f} rem={remaining:4.2f} | '
            f'pwm={self.pwm_cmd:5.1f} steer={self.steer_deg_cmd:+5.1f} servo={int(self.servo_us_cmd)} | '
            f'idx={self.closest_idx:03d} IMU={int(self.imu_ok)}     ',
            end='',
            flush=True,
        )

    # ============================================================
    # Main loop
    # ============================================================
    def loop(self):
        # Keyboard first for fast emergency stop.
        if hasattr(self, 'keyboard'):
            self.handle_key(self.keyboard.get_key())

        # Serial read.
        for line in self.read_serial_packets():
            state = self.parse_state_line(line)
            if state is None:
                continue

            self.imu_ok = (state['imu_ok'] == 1)

            if self.mode == 'CALIBRATING':
                self.update_calibration(state)
            else:
                self.update_localization(state)

        # Control only after state updates.
        if self.auto_enabled and self.mode == 'AUTO':
            self.compute_control()

        self.publish_basic_topics()
        self.print_dashboard()

        if self.quit_requested:
            raise KeyboardInterrupt

    def run(self):
        with KeyboardReader() as kb:
            self.keyboard = kb
            try:
                while rclpy.ok():
                    rclpy.spin_once(self, timeout_sec=0.02)
            except KeyboardInterrupt:
                pass
            finally:
                print('\nStopping Scenario 3 geometry node safely...')
                self.stop_car()
                time.sleep(0.05)
                self.send_command(0, self.servo_center_us)
                self.ser.close()


def main(args=None):
    rclpy.init(args=args)
    node = Scenario3CityTrackGeometry()
    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
