#!/usr/bin/env python3

import math

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64


def quaternion_to_yaw(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)

    return math.atan2(siny_cosp, cosy_cosp)


def normalize_angle(angle):
    while angle > math.pi:
        angle -= 2.0 * math.pi

    while angle < -math.pi:
        angle += 2.0 * math.pi

    return angle


class MS4StanleyLateralController(Node):
    """
    Improved Stanley controller.

    This version subscribes to:
        /model/vehicle_blue/odometry
        /ms4/desired_lane_y
        /ms4/desired_yaw

    This is important because during a lane change, desired_yaw is not zero.
    """

    def __init__(self):
        super().__init__("Autonomous_Systems_MS_4_Stanley_Lateral_Team_19")

        self.declare_parameter("odom_topic", "/model/vehicle_blue/odometry")
        self.declare_parameter("desired_lane_topic", "/ms4/desired_lane_y")
        self.declare_parameter("desired_yaw_topic", "/ms4/desired_yaw")
        self.declare_parameter("steering_cmd_topic", "/ms3/steering_cmd")

        self.declare_parameter("stanley_gain", 0.55)
        self.declare_parameter("softening_gain", 0.45)
        self.declare_parameter("heading_gain", 1.8)

        self.declare_parameter("max_steering_angle", 0.24)
        self.declare_parameter("minimum_speed_for_stanley", 0.08)

        self.declare_parameter("steering_sign", 1.0)

        self.declare_parameter("steering_filter_alpha", 0.25)
        self.declare_parameter("max_steering_rate", 0.45)

        self.declare_parameter("control_rate", 40.0)
        self.declare_parameter("odom_timeout", 1.0)

        self.odom_topic = str(self.get_parameter("odom_topic").value)
        self.desired_lane_topic = str(self.get_parameter("desired_lane_topic").value)
        self.desired_yaw_topic = str(self.get_parameter("desired_yaw_topic").value)
        self.steering_cmd_topic = str(self.get_parameter("steering_cmd_topic").value)

        self.k = float(self.get_parameter("stanley_gain").value)
        self.ks = float(self.get_parameter("softening_gain").value)
        self.heading_gain = float(self.get_parameter("heading_gain").value)

        self.max_steering_angle = float(self.get_parameter("max_steering_angle").value)
        self.minimum_speed_for_stanley = float(
            self.get_parameter("minimum_speed_for_stanley").value
        )

        self.steering_sign = float(self.get_parameter("steering_sign").value)

        self.filter_alpha = float(self.get_parameter("steering_filter_alpha").value)
        self.max_steering_rate = float(self.get_parameter("max_steering_rate").value)

        self.odom_timeout = float(self.get_parameter("odom_timeout").value)

        self.x = 0.0
        self.y = 0.0
        self.yaw = 0.0
        self.speed = 0.0

        self.desired_y = 0.1875
        self.desired_yaw = 0.0

        self.last_odom_time = None
        self.last_control_time = self.get_clock().now()

        self.filtered_steering = 0.0

        self.create_subscription(
            Odometry,
            self.odom_topic,
            self.odom_callback,
            20,
        )

        self.create_subscription(
            Float64,
            self.desired_lane_topic,
            self.desired_lane_callback,
            20,
        )

        self.create_subscription(
            Float64,
            self.desired_yaw_topic,
            self.desired_yaw_callback,
            20,
        )

        self.steering_pub = self.create_publisher(
            Float64,
            self.steering_cmd_topic,
            20,
        )

        control_rate = float(self.get_parameter("control_rate").value)
        self.timer = self.create_timer(1.0 / control_rate, self.control_loop)

        self.get_logger().info("Improved Stanley lateral controller started.")

    @staticmethod
    def clamp(value, low, high):
        return max(low, min(high, value))

    def desired_lane_callback(self, msg):
        self.desired_y = float(msg.data)

    def desired_yaw_callback(self, msg):
        self.desired_yaw = float(msg.data)

    def odom_callback(self, msg):
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y
        self.yaw = quaternion_to_yaw(msg.pose.pose.orientation)

        vx = msg.twist.twist.linear.x
        vy = msg.twist.twist.linear.y

        self.speed = math.sqrt(vx * vx + vy * vy)

        self.last_odom_time = self.get_clock().now()

    def apply_rate_limit(self, target_steering, dt):
        max_step = self.max_steering_rate * dt

        lower = self.filtered_steering - max_step
        upper = self.filtered_steering + max_step

        return self.clamp(target_steering, lower, upper)

    def control_loop(self):
        msg = Float64()

        now = self.get_clock().now()
        dt = (now - self.last_control_time).nanoseconds * 1e-9
        self.last_control_time = now
        dt = max(dt, 1e-3)

        if self.last_odom_time is None:
            msg.data = 0.0
            self.steering_pub.publish(msg)
            return

        odom_age = (now - self.last_odom_time).nanoseconds * 1e-9

        if odom_age > self.odom_timeout:
            msg.data = 0.0
            self.steering_pub.publish(msg)
            self.get_logger().warn(
                "Odometry timeout. Steering set to zero.",
                throttle_duration_sec=1.0,
            )
            return

        cross_track_error = self.desired_y - self.y

        heading_error = normalize_angle(self.desired_yaw - self.yaw)

        effective_speed = max(self.speed, self.minimum_speed_for_stanley)

        cte_term = math.atan2(
            self.k * cross_track_error,
            effective_speed + self.ks,
        )

        raw_steering = self.heading_gain * heading_error + cte_term
        raw_steering *= self.steering_sign

        raw_steering = self.clamp(
            raw_steering,
            -self.max_steering_angle,
            self.max_steering_angle,
        )

        rate_limited = self.apply_rate_limit(raw_steering, dt)

        self.filtered_steering = (
            self.filter_alpha * rate_limited
            + (1.0 - self.filter_alpha) * self.filtered_steering
        )

        msg.data = float(self.filtered_steering)
        self.steering_pub.publish(msg)

        self.get_logger().info(
            f"[Stanley] "
            f"x={self.x:.2f}, "
            f"y={self.y:.3f}, "
            f"desired_y={self.desired_y:.3f}, "
            f"desired_yaw={self.desired_yaw:.3f}, "
            f"cte={cross_track_error:.3f}, "
            f"yaw={self.yaw:.3f}, "
            f"heading_error={heading_error:.3f}, "
            f"speed={self.speed:.2f}, "
            f"steering={self.filtered_steering:.3f}",
            throttle_duration_sec=0.5,
        )


def main(args=None):
    rclpy.init(args=args)

    node = MS4StanleyLateralController()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
