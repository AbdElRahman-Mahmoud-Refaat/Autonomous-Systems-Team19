#!/usr/bin/env python3

import math

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64


class PID:
    def __init__(self, kp, ki, kd, output_min, output_max, integral_limit):
        self.kp = kp
        self.ki = ki
        self.kd = kd

        self.output_min = output_min
        self.output_max = output_max
        self.integral_limit = integral_limit

        self.integral = 0.0
        self.prev_error = 0.0
        self.first = True

    @staticmethod
    def clamp(value, low, high):
        return max(low, min(high, value))

    def update(self, error, dt):
        dt = max(dt, 1e-3)

        self.integral += error * dt
        self.integral = self.clamp(
            self.integral,
            -self.integral_limit,
            self.integral_limit,
        )

        if self.first:
            derivative = 0.0
            self.first = False
        else:
            derivative = (error - self.prev_error) / dt

        self.prev_error = error

        output = self.kp * error + self.ki * self.integral + self.kd * derivative

        return self.clamp(output, self.output_min, self.output_max)


class MS4SpeedController(Node):
    def __init__(self):
        super().__init__("Autonomous_Systems_MS_4_Speed_Controller_Team_19")

        self.declare_parameter("odom_topic", "/model/vehicle_blue/odometry")
        self.declare_parameter("desired_speed_topic", "/ms4/desired_speed")
        self.declare_parameter("speed_cmd_topic", "/ms3/speed_cmd")

        self.declare_parameter("fallback_speed", 0.8)

        self.declare_parameter("kp", 1.8)
        self.declare_parameter("ki", 0.15)
        self.declare_parameter("kd", 0.05)

        self.declare_parameter("max_speed_cmd", 2.5)
        self.declare_parameter("min_speed_cmd", -0.5)

        self.declare_parameter("integral_limit", 2.0)
        self.declare_parameter("control_rate", 30.0)
        self.declare_parameter("deadband", 0.03)
        self.declare_parameter("odom_timeout", 0.8)

        self.odom_topic = str(self.get_parameter("odom_topic").value)
        self.desired_speed_topic = str(self.get_parameter("desired_speed_topic").value)
        self.speed_cmd_topic = str(self.get_parameter("speed_cmd_topic").value)

        self.target_speed = float(self.get_parameter("fallback_speed").value)
        self.current_speed = 0.0

        self.last_odom_time = None
        self.last_control_time = self.get_clock().now()

        self.deadband = float(self.get_parameter("deadband").value)
        self.odom_timeout = float(self.get_parameter("odom_timeout").value)

        self.pid = PID(
            float(self.get_parameter("kp").value),
            float(self.get_parameter("ki").value),
            float(self.get_parameter("kd").value),
            float(self.get_parameter("min_speed_cmd").value),
            float(self.get_parameter("max_speed_cmd").value),
            float(self.get_parameter("integral_limit").value),
        )

        self.create_subscription(
            Odometry,
            self.odom_topic,
            self.odom_callback,
            20,
        )

        self.create_subscription(
            Float64,
            self.desired_speed_topic,
            self.desired_speed_callback,
            20,
        )

        self.pub_speed = self.create_publisher(
            Float64,
            self.speed_cmd_topic,
            20,
        )

        rate = float(self.get_parameter("control_rate").value)
        self.timer = self.create_timer(1.0 / rate, self.control_loop)

        self.get_logger().info(
            "MS4 Speed Controller started. Target speed comes from /ms4/desired_speed."
        )

    def desired_speed_callback(self, msg):
        self.target_speed = max(0.0, float(msg.data))

    def odom_callback(self, msg):
        vx = msg.twist.twist.linear.x
        vy = msg.twist.twist.linear.y

        self.current_speed = math.sqrt(vx * vx + vy * vy)
        self.last_odom_time = self.get_clock().now()

    def control_loop(self):
        now = self.get_clock().now()

        dt = (now - self.last_control_time).nanoseconds * 1e-9
        self.last_control_time = now

        out = Float64()

        if self.last_odom_time is None:
            out.data = 0.0
            self.pub_speed.publish(out)
            return

        if (now - self.last_odom_time).nanoseconds * 1e-9 > self.odom_timeout:
            out.data = 0.0
            self.pub_speed.publish(out)
            self.get_logger().warn(
                "Odometry timeout. Speed command forced to zero.",
                throttle_duration_sec=1.0,
            )
            return

        error = self.target_speed - self.current_speed

        if abs(error) < self.deadband:
            error = 0.0

        out.data = float(self.target_speed)
        self.pub_speed.publish(out)

        self.get_logger().info(
            f"[MS4 Speed] desired={self.target_speed:.2f}, "
            f"actual={self.current_speed:.2f}, "
            f"cmd={out.data:.2f}",
            throttle_duration_sec=0.5,
        )


def main(args=None):
    rclpy.init(args=args)

    node = MS4SpeedController()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
