#!/usr/bin/env python3

import math

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry, Path
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Float64, String


class MS4UnifiedPlannerTeam19(Node):
    def __init__(self):
        super().__init__("Autonomous_Systems_MS_4_Planning_Team_19")

        # =========================
        # Parameters
        # =========================
        self.declare_parameter("map_id", 1)
        self.declare_parameter("odom_topic", "/model/vehicle_blue/odometry")

        self.declare_parameter("track_length", 57.5)

        self.declare_parameter("lane1_y", 0.1875)
        self.declare_parameter("lane2_y", -0.1875)

        self.declare_parameter("max_speed", 0.30)
        self.declare_parameter("lane_change_speed", 0.15)
        self.declare_parameter("curve_speed", 0.12)

        self.declare_parameter("track1_finish_x", 36.0)
        self.declare_parameter("track2_finish_x", 55.0)
        self.declare_parameter("track3_finish_x", 72.0)

        self.declare_parameter("publish_rate", 40.0)

        self.map_id = int(self.get_parameter("map_id").value)
        self.odom_topic = str(self.get_parameter("odom_topic").value)

        self.track_length = float(self.get_parameter("track_length").value)

        self.lane1_y = float(self.get_parameter("lane1_y").value)
        self.lane2_y = float(self.get_parameter("lane2_y").value)

        self.max_speed = float(self.get_parameter("max_speed").value)
        self.lane_change_speed = float(self.get_parameter("lane_change_speed").value)
        self.curve_speed = float(self.get_parameter("curve_speed").value)

        self.track1_finish_x = float(self.get_parameter("track1_finish_x").value)
        self.track2_finish_x = float(self.get_parameter("track2_finish_x").value)
        self.track3_finish_x = float(self.get_parameter("track3_finish_x").value)

        # Same odom scale used in your Track-2-only planner.
        self.odom_scale = 5.75

        # =========================
        # Vehicle state
        # =========================
        self.current_x = 0.0
        self.current_y = 0.0

        self.start_x = None
        self.start_y = None

        self.prev_x = None
        self.prev_y = None

        # Track 1 and Track 2 use progress_x because they are straight tracks.
        self.progress_x = 0.0

        # Track 3 uses actual accumulated distance around the city track.
        self.distance_traveled = 0.0

        self.last_odom_received = False

        # =========================
        # Subscribers / Publishers
        # =========================
        self.create_subscription(
            Odometry,
            self.odom_topic,
            self.odom_callback,
            20,
        )

        self.pub_speed = self.create_publisher(Float64, "/ms4/desired_speed", 20)
        self.pub_lane_y = self.create_publisher(Float64, "/ms4/desired_lane_y", 20)
        self.pub_yaw = self.create_publisher(Float64, "/ms4/desired_yaw", 20)
        self.pub_state = self.create_publisher(String, "/ms4/planner_state", 20)
        self.pub_path = self.create_publisher(Path, "/ms4/desired_path", 10)

        rate = float(self.get_parameter("publish_rate").value)
        self.timer = self.create_timer(1.0 / rate, self.publish_plan)

        self.get_logger().info(
            f"Unified MS4 Planning Node Team 19 started with map_id={self.map_id}"
        )

    # ==========================================================
    # Helper functions
    # ==========================================================
    @staticmethod
    def clamp(value, low, high):
        return max(low, min(high, value))

    @staticmethod
    def quintic_smoothstep(t: float) -> float:
        t = max(0.0, min(1.0, t))
        return t * t * t * (10.0 - 15.0 * t + 6.0 * t * t)

    @staticmethod
    def quintic_smoothstep_derivative(t: float) -> float:
        t = max(0.0, min(1.0, t))
        return 30.0 * t * t * (1.0 - t) * (1.0 - t)

    def odom_callback(self, msg: Odometry):
        self.current_x = msg.pose.pose.position.x
        self.current_y = msg.pose.pose.position.y

        if self.start_x is None:
            self.start_x = self.current_x
            self.start_y = self.current_y
            self.prev_x = self.current_x
            self.prev_y = self.current_y
            self.last_odom_received = True
            return

        # Track 1 and Track 2 progress: straight-track style
        self.progress_x = abs(self.current_x - self.start_x)

        # Track 3 progress: real traveled distance around the city track
        dx = self.current_x - self.prev_x
        dy = self.current_y - self.prev_y

        step_distance = math.sqrt(dx * dx + dy * dy)

        # Avoid adding unrealistically large jumps caused by reset/glitch.
        if step_distance < 0.20:
            self.distance_traveled += step_distance

        self.prev_x = self.current_x
        self.prev_y = self.current_y

        self.last_odom_received = True

    # ==========================================================
    # Track 1: Empty track
    # ==========================================================
    def reference_track1(self, x: float):
        desired_y = 0.0
        desired_yaw = 0.0
        is_slow_region = False
        state = "TRACK_1_STRAIGHT"
        finish_x = self.track1_finish_x

        return desired_y, desired_yaw, is_slow_region, state, finish_x

    # ==========================================================
    # Track 2: copied from your Track-2-only planner logic
    # ==========================================================
    def reference_track2(self, x: float):
        x = self.clamp(x, 0.0, self.track_length)

        lane1 = self.lane1_y
        lane2 = self.lane2_y

        # Segment 1: Start in Lane 1.
        if x < 9.0:
            y = lane1
            dydx = 0.0
            state = "KEEP_LANE_1"

        # Segment 2: Smooth lane change Lane 1 -> Lane 2.
        elif x < 15.0:
            x0 = 9.0
            x1 = 15.0
            t = (x - x0) / (x1 - x0)
            s = self.quintic_smoothstep(t)
            dsdt = self.quintic_smoothstep_derivative(t)

            y = lane1 + s * (lane2 - lane1)
            dydx = (lane2 - lane1) * dsdt / (x1 - x0)
            state = "LANE_CHANGE_TO_LANE_2"

        # Segment 3: Keep Lane 2 past obstacle 1.
        elif x < 25.0:
            y = lane2
            dydx = 0.0
            state = "KEEP_LANE_2"

        # Segment 4: Smooth lane change Lane 2 -> Lane 1.
        elif x < 32.0:
            x0 = 25.0
            x1 = 32.0
            t = (x - x0) / (x1 - x0)
            s = self.quintic_smoothstep(t)
            dsdt = self.quintic_smoothstep_derivative(t)

            y = lane2 + s * (lane1 - lane2)
            dydx = (lane1 - lane2) * dsdt / (x1 - x0)
            state = "LANE_CHANGE_TO_LANE_1"

        # Segment 5: Keep Lane 1 to finish.
        else:
            y = lane1
            dydx = 0.0
            state = "KEEP_LANE_1"

        desired_yaw = math.atan2(dydx * self.odom_scale, 1.0)

        is_slow_region = "LANE_CHANGE" in state
        finish_x = self.track2_finish_x

        return y, desired_yaw, is_slow_region, state, finish_x

    # ==========================================================
    # Track 3: uses PROGRESS = distance_traveled
    # ==========================================================
    def reference_track3(self, x: float):
    """
    Track 3 city track - Counter-Clockwise (CCW) lap.

    IMPORTANT:
    Here x is distance_traveled around the city track.
    
    CCW Path: 
    Start -> Straight (east) -> Turn LEFT (north) -> Straight (north) -> 
    Turn LEFT (west) -> Straight (west) -> Turn LEFT (south) -> 
    Straight (south) -> Turn LEFT (east) -> Complete lap
    """
        desired_y = self.current_y  # Keep current y position
        # Segment 1: First straight (moving east/forward along +x axis)
        if x < 17.2:
           desired_yaw = 0.0      # Facing east (0 radians)
           state = "CITY_STRAIGHT_1"
        # Corner 1: Turn LEFT to face north
        elif x < 19.1:
           desired_yaw = 1.57     # +90 degrees (facing north)
           state = "CITY_TURN_1_LEFT"
        # Segment 2: Moving north (along +y axis)
        elif x < 30.7:
           desired_yaw = 1.57     # Still facing north
           state = "CITY_STRAIGHT_2"
        # Corner 2: Turn LEFT to face west
        elif x < 32.2:
           desired_yaw = 3.14     # +180 degrees (facing west)
           state = "CITY_TURN_2_LEFT"
        # Segment 3: Moving west (along -x axis)
        elif x < 47.3:
           desired_yaw = 3.14     # Still facing west
           state = "CITY_STRAIGHT_3"
        # Corner 3: Turn LEFT to face south
        elif x < 52.0:
           desired_yaw = -1.57    # -90 degrees (facing south)
           state = "CITY_TURN_3_LEFT"
        # Segment 4: Moving south (along -y axis)
        elif x < 64.0:
           desired_yaw = -1.57    # Still facing south
           state = "CITY_STRAIGHT_4"
        # Corner 4: Turn LEFT to face east again (complete the lap)
        elif x < 69.0:
           desired_yaw = 0.0      # Back to facing east
           state = "CITY_TURN_4_LEFT"
        # Finish lap (back at start position)
        else:
           desired_yaw = 0.0
           state = "CITY_LAP_COMPLETE"
        # Slow down only during actual turns
        is_slow_region = "TURN" in state
        finish_x = self.track3_finish_x
        return desired_y, desired_yaw, is_slow_region, state, finish_x

    def get_reference(self, planning_progress: float):
        if self.map_id == 1:
            return self.reference_track1(planning_progress)

        if self.map_id == 2:
            return self.reference_track2(planning_progress)

        if self.map_id == 3:
            return self.reference_track3(planning_progress)

        self.get_logger().warn(
            f"Invalid map_id={self.map_id}. Falling back to Track 1.",
            throttle_duration_sec=1.0,
        )
        return self.reference_track1(planning_progress)

    def publish_reference_path(self):
        path = Path()
        path.header.frame_id = "world"
        path.header.stamp = self.get_clock().now().to_msg()

        x = 0.0

        while x <= self.track_length:
            y, yaw, _, _, _ = self.get_reference(x)

            pose = PoseStamped()
            pose.header = path.header
            pose.pose.position.x = float(x)
            pose.pose.position.y = float(y)
            pose.pose.position.z = 0.0

            pose.pose.orientation.z = math.sin(yaw / 2.0)
            pose.pose.orientation.w = math.cos(yaw / 2.0)

            path.poses.append(pose)
            x += 0.10

        self.pub_path.publish(path)

    def publish_plan(self):
        # This is the important part:
        # Track 1 and Track 2 use progress_x.
        # Track 3 uses distance_traveled.
        if self.map_id == 3:
            planning_progress = self.distance_traveled
        else:
            planning_progress = self.progress_x

        desired_y, desired_yaw, is_slow_region, state_name, finish_x = self.get_reference(
            planning_progress
        )

        if not self.last_odom_received:
            desired_speed = 0.0
            state = f"MAP_{self.map_id}_WAITING_FOR_ODOMETRY"

        elif planning_progress >= finish_x:
            desired_speed = 0.0
            state = f"MAP_{self.map_id}_FINISH_STOP"

        else:
            if self.map_id == 3 and is_slow_region:
                desired_speed = self.curve_speed
            elif is_slow_region:
                desired_speed = self.lane_change_speed
            else:
                desired_speed = self.max_speed

            state = f"MAP_{self.map_id}_{state_name}"

        speed_msg = Float64()
        speed_msg.data = float(desired_speed)
        self.pub_speed.publish(speed_msg)

        lane_msg = Float64()
        lane_msg.data = float(desired_y)
        self.pub_lane_y.publish(lane_msg)

        yaw_msg = Float64()
        yaw_msg.data = float(desired_yaw)
        self.pub_yaw.publish(yaw_msg)

        state_msg = String()
        state_msg.data = (
            f"{state} | "
            f"x={self.current_x:.2f} | "
            f"progress={planning_progress:.2f} | "
            f"raw_progress_x={self.progress_x:.2f} | "
            f"distance={self.distance_traveled:.2f} | "
            f"y={self.current_y:.3f} | "
            f"desired_y={desired_y:.3f} | "
            f"desired_yaw={desired_yaw:.3f} | "
            f"speed={desired_speed:.2f}"
        )

        self.pub_state.publish(state_msg)
        self.publish_reference_path()

        self.get_logger().info(state_msg.data, throttle_duration_sec=0.5)


def main(args=None):
    rclpy.init(args=args)

    node = MS4UnifiedPlannerTeam19()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
