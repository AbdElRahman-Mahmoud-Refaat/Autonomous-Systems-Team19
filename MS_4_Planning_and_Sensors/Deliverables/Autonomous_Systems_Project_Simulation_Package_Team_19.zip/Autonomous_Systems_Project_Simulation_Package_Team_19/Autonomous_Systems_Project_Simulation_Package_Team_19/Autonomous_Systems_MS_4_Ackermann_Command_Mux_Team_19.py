#!/usr/bin/env python3

import math

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Float64


class MS4AckermannCommandMux(Node):
    """
    Converts speed command and Stanley steering angle to Gazebo cmd_vel.

    Inputs:
        /ms3/speed_cmd       Float64
        /ms3/steering_cmd    Float64

    Output:
        /model/vehicle_blue/cmd_vel  geometry_msgs/Twist

    For Ackermann approximation:
        angular.z = v / L * tan(delta)

    where:
        v     = linear speed
        L     = wheel base
        delta = Stanley steering angle
    """

    def __init__(self):
        super().__init__("Autonomous_Systems_MS_4_Ackermann_Command_Mux_Team_19")

        self.declare_parameter("speed_cmd_topic", "/ms3/speed_cmd")
        self.declare_parameter("steering_cmd_topic", "/ms3/steering_cmd")
        self.declare_parameter("cmd_vel_topic", "/model/vehicle_blue/cmd_vel")

        self.declare_parameter("wheel_base", 0.22)

        self.declare_parameter("max_linear_speed", 0.45)
        self.declare_parameter("max_steering_angle", 0.30)
        self.declare_parameter("max_yaw_rate", 1.0)

        self.declare_parameter("publish_rate", 40.0)
        self.declare_parameter("command_timeout", 1.0)

        self.speed_cmd_topic = str(self.get_parameter("speed_cmd_topic").value)
        self.steering_cmd_topic = str(self.get_parameter("steering_cmd_topic").value)
        self.cmd_vel_topic = str(self.get_parameter("cmd_vel_topic").value)

        self.wheel_base = float(self.get_parameter("wheel_base").value)

        self.max_linear_speed = float(self.get_parameter("max_linear_speed").value)
        self.max_steering_angle = float(self.get_parameter("max_steering_angle").value)
        self.max_yaw_rate = float(self.get_parameter("max_yaw_rate").value)

        self.command_timeout = float(self.get_parameter("command_timeout").value)

        self.speed_cmd = 0.0
        self.steering_angle = 0.0

        self.last_speed_time = None
        self.last_steering_time = None

        self.create_subscription(
            Float64,
            self.speed_cmd_topic,
            self.speed_callback,
            20,
        )

        self.create_subscription(
            Float64,
            self.steering_cmd_topic,
            self.steering_callback,
            20,
        )

        self.pub_cmd_vel = self.create_publisher(
            Twist,
            self.cmd_vel_topic,
            20,
        )

        rate = float(self.get_parameter("publish_rate").value)
        self.timer = self.create_timer(1.0 / rate, self.publish_cmd)

        self.get_logger().info("Ackermann command mux started.")

    @staticmethod
    def clamp(value, low, high):
        return max(low, min(high, value))

    def speed_callback(self, msg):
        self.speed_cmd = float(msg.data)
        self.last_speed_time = self.get_clock().now()

    def steering_callback(self, msg):
        self.steering_angle = float(msg.data)
        self.last_steering_time = self.get_clock().now()

    def command_is_fresh(self):
        """
        Require fresh speed command.

        If steering command is missing or old, steering becomes zero,
        but the car can still move straight.
        """
        now = self.get_clock().now()

        if self.last_speed_time is None:
            return False

        speed_age = (now - self.last_speed_time).nanoseconds * 1e-9

        if speed_age > self.command_timeout:
            return False

        if self.last_steering_time is None:
            self.steering_angle = 0.0
            return True

        steering_age = (now - self.last_steering_time).nanoseconds * 1e-9

        if steering_age > self.command_timeout:
            self.steering_angle = 0.0

        return True

    def publish_cmd(self):
        msg = Twist()

        if not self.command_is_fresh():
            msg.linear.x = 0.0
            msg.angular.z = 0.0
            self.pub_cmd_vel.publish(msg)
            return

        v = self.clamp(
            self.speed_cmd,
            -self.max_linear_speed,
            self.max_linear_speed,
        )

        delta = self.clamp(
            self.steering_angle,
            -self.max_steering_angle,
            self.max_steering_angle,
        )

        yaw_rate = 0.0

        if abs(self.wheel_base) > 1e-6:
            yaw_rate = (v / self.wheel_base) * math.tan(delta)

        yaw_rate = self.clamp(
            yaw_rate,
            -self.max_yaw_rate,
            self.max_yaw_rate,
        )

        msg.linear.x = float(v)
        msg.angular.z = float(yaw_rate)

        self.pub_cmd_vel.publish(msg)

        self.get_logger().info(
            f"[Ackermann Mux] "
            f"v={v:.2f}, "
            f"delta={delta:.3f}, "
            f"yaw_rate={yaw_rate:.3f}",
            throttle_duration_sec=0.5,
        )


def main(args=None):
    rclpy.init(args=args)

    node = MS4AckermannCommandMux()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
