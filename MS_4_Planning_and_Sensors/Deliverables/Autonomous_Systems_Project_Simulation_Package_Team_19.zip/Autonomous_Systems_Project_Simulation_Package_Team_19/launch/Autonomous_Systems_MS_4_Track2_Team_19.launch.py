from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, TimerAction
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution, PythonExpression

from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():

    package_name = "Autonomous_Systems_Project_Simulation_Package_Team_19"

    map_id = LaunchConfiguration("map_id")
    launch_gazebo = LaunchConfiguration("launch_gazebo")
    launch_rqt_graph = LaunchConfiguration("launch_rqt_graph")

    max_speed = LaunchConfiguration("max_speed")
    lane_change_speed = LaunchConfiguration("lane_change_speed")

    odom_topic = "/model/vehicle_blue/odometry"
    cmd_vel_topic = "/model/vehicle_blue/cmd_vel"

    track1_world = PathJoinSubstitution(
        [
            FindPackageShare(package_name),
            "Worlds",
            "Empty_Track.world",
        ]
    )

    track2_world = PathJoinSubstitution(
        [
            FindPackageShare(package_name),
            "Worlds",
            "Racing_Track.world",
        ]
    )

    track3_world = PathJoinSubstitution(
        [
            FindPackageShare(package_name),
            "Worlds",
            "City_Track.world",
        ]
    )

    is_track1_or_2_or_3 = PythonExpression(
        [
            "'", map_id, "' == '1' or '",
            map_id, "' == '2' or '",
            map_id, "' == '3'"
        ]
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument("map_id", default_value="1"),
            DeclareLaunchArgument("launch_gazebo", default_value="true"),
            DeclareLaunchArgument("launch_rqt_graph", default_value="false"),

            DeclareLaunchArgument("max_speed", default_value="0.30"),
            DeclareLaunchArgument("lane_change_speed", default_value="0.15"),

            # =========================
            # Gazebo worlds
            # =========================
            ExecuteProcess(
                cmd=["gz", "sim", "-r", track1_world],
                output="screen",
                condition=IfCondition(
                    PythonExpression(
                        ["'", map_id, "' == '1' and '", launch_gazebo, "' == 'true'"]
                    )
                ),
            ),

            ExecuteProcess(
                cmd=["gz", "sim", "-r", track2_world],
                output="screen",
                condition=IfCondition(
                    PythonExpression(
                        ["'", map_id, "' == '2' and '", launch_gazebo, "' == 'true'"]
                    )
                ),
            ),

            ExecuteProcess(
                cmd=["gz", "sim", "-r", track3_world],
                output="screen",
                condition=IfCondition(
                    PythonExpression(
                        ["'", map_id, "' == '3' and '", launch_gazebo, "' == 'true'"]
                    )
                ),
            ),

            # =========================
            # ROS-Gazebo bridge
            # =========================
            Node(
                package="ros_gz_bridge",
                executable="parameter_bridge",
                name="ms4_ros_gz_bridge_team19",
                output="screen",
                arguments=[
                    "/model/vehicle_blue/odometry@nav_msgs/msg/Odometry[gz.msgs.Odometry",
                    "/model/vehicle_blue/cmd_vel@geometry_msgs/msg/Twist]gz.msgs.Twist",
                ],
            ),

            # =========================
            # Unified planning node
            # =========================
            Node(
                package=package_name,
                executable="Autonomous_Systems_MS_4_Planning_Team_19",
                name="Autonomous_Systems_MS_4_Planning_Team_19",
                output="screen",
                parameters=[
                    {
                        "map_id": map_id,
                        "odom_topic": odom_topic,

                        "track_length": 57.5,
                        "lane1_y": 0.1875,
                        "lane2_y": -0.1875,

                        "max_speed": max_speed,
                        "lane_change_speed": lane_change_speed,
                        "curve_speed": 0.12,

                        # Track 1 kept as before from your scaled test
                        "track1_finish_x": 38.0,

                        # Track 2 copied from your Track-2-only launch
                        "track2_finish_x": 55.0,

                        # Track 3 placeholder value
                        "track3_finish_x": 70.0,

                        "publish_rate": 40.0,
                    }
                ],
            ),

            # =========================
            # Speed controller: all tracks
            # =========================
            Node(
                package=package_name,
                executable="Autonomous_Systems_MS_4_Speed_Controller_Team_19",
                name="Autonomous_Systems_MS_4_Speed_Controller_Team_19",
                output="screen",
                condition=IfCondition(is_track1_or_2_or_3),
                parameters=[
                    {
                        "odom_topic": odom_topic,
                        "desired_speed_topic": "/ms4/desired_speed",
                        "speed_cmd_topic": "/ms3/speed_cmd",

                        "fallback_speed": 0.0,

                        "kp": 1.8,
                        "ki": 0.15,
                        "kd": 0.05,

                        "max_speed_cmd": 2.5,
                        "min_speed_cmd": -0.5,
                        "integral_limit": 2.0,

                        "control_rate": 30.0,
                        "deadband": 0.03,
                        "odom_timeout": 0.8,
                    }
                ],
            ),

            # =========================
            # Stanley lateral controller:
            # Track 2 and Track 3 only
            # =========================
            Node(
                package=package_name,
                executable="Autonomous_Systems_MS_4_Stanley_Lateral_Team_19",
                name="Autonomous_Systems_MS_4_Stanley_Lateral_Team_19",
                output="screen",
                condition=IfCondition(
                    PythonExpression(
                        ["'", map_id, "' == '1' or '", map_id, "' == '2'or '", map_id, "' == '3'"]
                    )
                ),
                parameters=[
                    {
                        "odom_topic": odom_topic,
                        "desired_lane_topic": "/ms4/desired_lane_y",
                        "desired_yaw_topic": "/ms4/desired_yaw",
                        "steering_cmd_topic": "/ms3/steering_cmd",

                        # Same as your Track-2-only launch
                        "stanley_gain": 1.10,
                        "softening_gain": 0.45,
                        "heading_gain": 2.6,

                        "max_steering_angle": 0.40,
                        "minimum_speed_for_stanley": 0.08,

                        "steering_sign": 1.0,

                        "steering_filter_alpha": 0.25,
                        "max_steering_rate": 0.65,

                        "control_rate": 40.0,
                        "odom_timeout": 1.0,
                    }
                ],
            ),

            # =========================
            # Ackermann command mux: all tracks
            # =========================
            Node(
                package=package_name,
                executable="Autonomous_Systems_MS_4_Ackermann_Command_Mux_Team_19",
                name="Autonomous_Systems_MS_4_Ackermann_Command_Mux_Team_19",
                output="screen",
                condition=IfCondition(is_track1_or_2_or_3),
                parameters=[
                    {
                        "speed_cmd_topic": "/ms3/speed_cmd",
                        "steering_cmd_topic": "/ms3/steering_cmd",
                        "cmd_vel_topic": cmd_vel_topic,

                        # Same as your Track-2-only launch
                        "wheel_base": 0.22,
                        "max_linear_speed": 0.45,
                        "max_steering_angle": 0.40,
                        "max_yaw_rate": 1.80,

                        "publish_rate": 40.0,
                        "command_timeout": 1.0,
                    }
                ],
            ),

            # =========================
            # Optional rqt_graph
            # =========================
            TimerAction(
                period=3.0,
                actions=[
                    ExecuteProcess(
                        cmd=["rqt_graph"],
                        output="screen",
                        condition=IfCondition(launch_rqt_graph),
                    )
                ],
            ),
        ]
    )
