from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'Autonomous_Systems_Project_Simulation_Package_Team_19'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
       (os.path.join("share", package_name, "Worlds"), glob("Worlds/*")),
(os.path.join("share", package_name, "launch"), glob("launch/*.launch.py")),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='lenovo',
    maintainer_email='lenovo@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
    "console_scripts": [
        "Autonomous_Systems_MS_4_Planning_Team_19 = Autonomous_Systems_Project_Simulation_Package_Team_19.Autonomous_Systems_MS_4_Planning_Team_19:main",
        "Autonomous_Systems_MS_4_Speed_Controller_Team_19 = Autonomous_Systems_Project_Simulation_Package_Team_19.Autonomous_Systems_MS_4_Speed_Controller_Team_19:main",
        "Autonomous_Systems_MS_4_Stanley_Lateral_Team_19 = Autonomous_Systems_Project_Simulation_Package_Team_19.Autonomous_Systems_MS_4_Stanley_Lateral_Team_19:main",
        "Autonomous_Systems_MS_4_Ackermann_Command_Mux_Team_19 = Autonomous_Systems_Project_Simulation_Package_Team_19.Autonomous_Systems_MS_4_Ackermann_Command_Mux_Team_19:main",
    ],
},
)
