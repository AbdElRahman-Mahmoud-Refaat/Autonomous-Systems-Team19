from launch import LaunchDescription
from launch.actions import ExecuteProcess, DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():

    init_x = LaunchConfiguration('init_x')
    init_y = LaunchConfiguration('init_y')
    init_yaw = LaunchConfiguration('init_yaw')
    desired_speed = LaunchConfiguration('desired_speed')
    desired_lane = LaunchConfiguration('desired_lane')

    return LaunchDescription([

        DeclareLaunchArgument(
            'init_x',
            default_value='0.0'
        ),

        DeclareLaunchArgument(
            'init_y',
            default_value='0.0'
        ),

        DeclareLaunchArgument(
            'init_yaw',
            default_value='0.0'
        ),

        DeclareLaunchArgument(
            'desired_speed',
            default_value='1.0'
        ),

        DeclareLaunchArgument(
            'desired_lane',
            default_value='0.0'
        ),

        # Gazebo world with vehicle_blue
        ExecuteProcess(
            cmd=['gz', 'sim', '/usr/share/gz/gz-sim8/worlds/ackermann_steering.sdf'],
            output='screen'
        ),

        # ROS -> Gazebo bridge for cmd_vel
        Node(
            package='ros_gz_bridge',
            executable='parameter_bridge',
            arguments=['/model/vehicle_blue/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist'],            output='screen'
        ),

        # Gazebo -> ROS bridge for odometry
        Node(
            package='ros_gz_bridge',
            executable='parameter_bridge',
            arguments=['/model/vehicle_blue/odometry@nav_msgs/msg/Odometry[gz.msgs.Odometry'],
            output='screen'
        ),

        # Speed controller node
        Node(
            package='Autonomous_Systems_Project_Team_19',
            executable='Autonomous_Systems_MS_3_CLR_Alg_1_Speed_Team_19',
            name='speed_controller',
            output='screen',
            parameters=[{
                'desired_speed': desired_speed
            }]
        ),
       #Lateral Controller Node
                Node(
            package='Autonomous_Systems_Project_Team_19',
            executable='Autonomous_Systems_MS_3_CLR_Alg_2_Lateral_Team_19',
            name='lateral_controller',
            output='screen',
            parameters=[{
                'desired_lane': desired_lane,
                'k_stanley': 0.4,
                'softening_gain': 0.5,
                'forward_speed': desired_speed,
                'desired_heading': init_yaw
            }]
        ),

        # rqt_graph
        Node(
            package='rqt_graph',
            executable='rqt_graph',
            name='rqt_graph',
            output='screen'
        ),
 
])
