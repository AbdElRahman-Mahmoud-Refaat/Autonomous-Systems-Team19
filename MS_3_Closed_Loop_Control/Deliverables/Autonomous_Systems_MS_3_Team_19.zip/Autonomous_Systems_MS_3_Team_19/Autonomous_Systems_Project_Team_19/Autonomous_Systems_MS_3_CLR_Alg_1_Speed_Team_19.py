#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64


class SpeedController(Node):
    def __init__(self):
        super().__init__('speed_controller')

        self.declare_parameter('desired_speed', 1.0)
        self.declare_parameter('kp', 1.0)

        self.desired_speed = self.get_parameter('desired_speed').value
        self.kp = self.get_parameter('kp').value

        self.actual_speed = 0.0

        self.odom_sub = self.create_subscription(
            Odometry,
            '/model/vehicle_blue/odometry',
            self.odom_callback,
            10
        )

        self.speed_effort_pub = self.create_publisher(
            Float64,
            '/speed_control_effort',
            10
        )

        self.timer = self.create_timer(0.1, self.control_loop)

        self.get_logger().info('Speed Controller Node Started')

    def odom_callback(self, msg):
        self.actual_speed = msg.twist.twist.linear.x

    def control_loop(self):
        error = self.desired_speed - self.actual_speed
        control_effort = self.kp * error

        msg = Float64()
        msg.data = control_effort
        self.speed_effort_pub.publish(msg)

        self.get_logger().info(
            f'Actual Speed: {self.actual_speed:.2f}, Error: {error:.2f}, Speed Control Effort: {control_effort:.2f}'
        )


def main(args=None):
    rclpy.init(args=args)
    node = SpeedController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
