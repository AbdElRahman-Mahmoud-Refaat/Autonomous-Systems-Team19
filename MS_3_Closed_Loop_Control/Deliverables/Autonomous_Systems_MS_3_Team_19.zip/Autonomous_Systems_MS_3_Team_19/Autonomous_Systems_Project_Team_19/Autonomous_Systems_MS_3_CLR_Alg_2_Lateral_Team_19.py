#!/usr/bin/env python3

import math
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
import csv
import time

class StanleyLateralController(Node):
    def __init__(self):
        super().__init__('lateral_controller')
        self.start_time = time.time()
        self.file = open('lateral_data.csv', 'w', newline='')
        self.writer = csv.writer(self.file)
        self.writer.writerow(['time', 'current_y', 'desired_lane', 'error'])
        # Parameters
        self.declare_parameter('desired_lane', 0.0)
        self.declare_parameter('k_stanley', 0.4)
        self.declare_parameter('softening_gain', 0.5)
        self.declare_parameter('forward_speed', 1.0)
        self.declare_parameter('desired_heading', 0.0)

        self.desired_lane = self.get_parameter('desired_lane').value
        self.k_stanley = self.get_parameter('k_stanley').value
        self.softening_gain = self.get_parameter('softening_gain').value
        self.forward_speed = self.get_parameter('forward_speed').value
        self.desired_heading = self.get_parameter('desired_heading').value

        self.current_y = 0.0
        self.current_yaw = 0.0
        self.current_speed = 0.0

        self.odom_sub = self.create_subscription(
            Odometry,
            '/model/vehicle_blue/odometry',
            self.odom_callback,
            10
        )

        self.cmd_pub = self.create_publisher(
            Twist,
            '/model/vehicle_blue/cmd_vel',
            10
        )

        self.timer = self.create_timer(0.1, self.control_loop)

        self.get_logger().info('Stanley Lateral Controller Node Started')

    def odom_callback(self, msg):
        self.current_y = msg.pose.pose.position.y
        self.current_speed = msg.twist.twist.linear.x

        q = msg.pose.pose.orientation
        self.current_yaw = self.quaternion_to_yaw(q.x, q.y, q.z, q.w)

    def quaternion_to_yaw(self, x, y, z, w):
        siny_cosp = 2.0 * (w * z + x * y)
        cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
        return math.atan2(siny_cosp, cosy_cosp)

    def normalize_angle(self, angle):
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle

    def control_loop(self):
        # Cross-track error: desired lane minus current lateral position
        cross_track_error = self.desired_lane - self.current_y

        # Heading error: desired heading minus current heading
        heading_error = self.normalize_angle(self.desired_heading - self.current_yaw)

        # Stanley law
        stanley_term = math.atan2(
            self.k_stanley * cross_track_error,
            self.softening_gain + abs(self.current_speed)
        )

        steering_command = heading_error + stanley_term

        # Optional saturation
        max_steer = 1.0
        steering_command = max(-max_steer, min(max_steer, steering_command))

        msg = Twist()
        msg.linear.x = self.forward_speed
        msg.angular.z = steering_command
        current_time = time.time() - self.start_time
        error = self.desired_lane - self.current_y
        self.writer.writerow([current_time, self.current_y, self.desired_lane, error])
        self.file.flush()
        self.cmd_pub.publish(msg)

        self.get_logger().info(
            f'y={self.current_y:.2f}, yaw={self.current_yaw:.2f}, '
            f'v={self.current_speed:.2f}, cte={cross_track_error:.2f}, '
            f'heading_err={heading_error:.2f}, steer={steering_command:.2f}'
        )


def main(args=None):
    rclpy.init(args=args)
    node = StanleyLateralController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.file.close()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
