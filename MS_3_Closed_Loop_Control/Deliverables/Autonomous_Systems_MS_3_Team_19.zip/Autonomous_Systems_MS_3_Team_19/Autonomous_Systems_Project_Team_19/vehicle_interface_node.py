import rclpy
from rclpy.node import Node

class VehicleInterfaceNode(Node):

    def __init__(self):
        super().__init__('vehicle_interface_node')
        self.get_logger().info('Vehicle Interface Node Started')

def main(args=None):
    rclpy.init(args=args)
    node = VehicleInterfaceNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
