// ===== Motor Driver Pins =====
const int PWM_PIN = 10;
const int IN1 = 5;
const int IN2 = 6;

// ===== Encoder =====
const int ENCODER_A = 2;

// ===== Control =====
float desiredRPM = 0;
float actualRPM = 0;
float error = 0;
float Kp = 1.5;

// ===== Encoder Specs =====
const float PPR = 374.0;

// ===== Timing =====
volatile long pulseCount = 0;
unsigned long lastTime = 0;
const unsigned long sampleTime = 100;   // ms

// ===== PWM =====
int pwmValue = 0;

void countEncoder() {
  pulseCount++;
}

void setup() {
  pinMode(PWM_PIN, OUTPUT);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(ENCODER_A, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(ENCODER_A), countEncoder, RISING);

  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);

  Serial.begin(9600);
  Serial.setTimeout(20);

  Serial.println("Type desired RPM and press Enter:");
}

void loop() {
  // Read desired RPM from Serial Monitor
  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    input.trim();

    if (input.length() > 0) {
      desiredRPM = input.toFloat();
      desiredRPM = constrain(desiredRPM, 0, 250);

      Serial.print("New desired RPM: ");
      Serial.println(desiredRPM);
    }
  }

  // Control loop every 100 ms
  if (millis() - lastTime >= sampleTime) {
    noInterrupts();
    long pulses = pulseCount;
    pulseCount = 0;
    interrupts();

    // RPM calculation
    actualRPM = (pulses * 60000.0) / (PPR * sampleTime);

    // P control
    error = desiredRPM - actualRPM;
    pwmValue += (int)(Kp * error);
    pwmValue = constrain(pwmValue, 0, 255);

    analogWrite(PWM_PIN, pwmValue);

    Serial.print("Desired: ");
    Serial.print(desiredRPM);
    Serial.print(" | Actual: ");
    Serial.print(actualRPM);
    Serial.print(" | PWM: ");
    Serial.println(pwmValue);

    lastTime = millis();
  }
}
