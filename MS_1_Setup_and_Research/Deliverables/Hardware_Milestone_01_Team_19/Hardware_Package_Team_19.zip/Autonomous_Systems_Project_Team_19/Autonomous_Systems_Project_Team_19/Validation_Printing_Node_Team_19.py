import rclpy
from rclpy.node import Node

class ValidationNode(Node):
    def __init__(self):
        super().__init__('Validation_Printing_Node_Team_19')
        self.get_logger().info('Hello World - Team 19')

def main(args=None):
    rclpy.init(args=args)
    node = ValidationNode()
    rclpy.spin_once(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
