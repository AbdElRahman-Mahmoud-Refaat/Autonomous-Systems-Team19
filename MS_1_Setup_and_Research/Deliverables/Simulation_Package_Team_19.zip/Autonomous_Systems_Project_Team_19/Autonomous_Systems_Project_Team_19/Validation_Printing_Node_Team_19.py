import rclpy
from rclpy.node import Node

class ValidationPrintingNodeTeam19(Node):
    def __init__(self):
        super().__init__('validation_printing_node_team_19')
        self.get_logger().info('Hello World from Team 19')

def main(args=None):
    rclpy.init(args=args)
    node = ValidationPrintingNodeTeam19()
    rclpy.spin_once(node, timeout_sec=1.0)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
