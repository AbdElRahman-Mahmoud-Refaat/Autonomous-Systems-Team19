from setuptools import find_packages, setup

package_name = 'Autonomous_Systems_Project_Team_19'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='lenovo',
    maintainer_email='lenovo@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
          'Validation_Printing_Node_Team_19 = Autonomous_Systems_Project_Team_19.Validation_Printing_Node_Team_19:main',
        ],
    },
)

