#!/usr/bin/env python3

import sys
import time
import termios
import tty
import select
import serial


MSG = """
Optimized Motor Teleop
----------------------
Hold Up Arrow   : accelerate forward
Hold Down Arrow : accelerate backward
s               : stop + clear memory + zero encoder
z               : zero encoder only
q               : stop + reset Arduino + quit
"""


def get_key(timeout=0.02):
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        rlist, _, _ = select.select([sys.stdin], [], [], timeout)
        if rlist:
            ch1 = sys.stdin.read(1)
            if ch1 == '\x1b':
                ch2 = sys.stdin.read(1)
                ch3 = sys.stdin.read(1)
                return ch1 + ch2 + ch3
            return ch1
        return ''
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


def main():
    port = '/dev/ttyACM0'
    if len(sys.argv) > 1:
        port = sys.argv[1]

    try:
        ser = serial.Serial(port, 115200, timeout=0.02)
        time.sleep(2.0)
    except Exception as e:
        print(f'Failed to open serial port: {e}')
        sys.exit(1)

    print(f'Connected to Arduino on {port} @ 115200')
    print(MSG)

    last_send = 0.0
    repeat_interval = 0.045   # fast repeat, low lag

    def send_cmd(cmd: str):
        nonlocal last_send
        ser.write((cmd + '\n').encode('utf-8'))
        last_send = time.time()

    try:
        while True:
            # show Arduino feedback
            try:
                while ser.in_waiting > 0:
                    line = ser.readline().decode('utf-8', errors='ignore').strip()
                    if line:
                        print(f'Arduino: {line}')
            except Exception:
                pass

            key = get_key()

            # keyboard auto-repeat while holding arrow usually generates repeated arrow codes
            if key == '\x1b[A':      # Up
                send_cmd('UP')
            elif key == '\x1b[B':    # Down
                send_cmd('DOWN')
            elif key.lower() == 's':
                send_cmd('CLEAR')
            elif key.lower() == 'z':
                send_cmd('ZEROENC')
            elif key.lower() == 'q':
                send_cmd('CLEAR')
                time.sleep(0.10)
                send_cmd('RESET')
                time.sleep(0.15)
                break

    finally:
        ser.close()
        print('Closed serial port')


if __name__ == '__main__':
    main()
